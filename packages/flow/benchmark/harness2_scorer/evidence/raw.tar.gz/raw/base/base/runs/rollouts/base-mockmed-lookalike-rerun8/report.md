status: saved

Triage encounter recorded for Jane Sample with note.
