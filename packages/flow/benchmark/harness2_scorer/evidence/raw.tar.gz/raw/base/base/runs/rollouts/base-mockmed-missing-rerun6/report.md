status: saved

Triage encounter for Jane Sample recorded with note and saved successfully.
