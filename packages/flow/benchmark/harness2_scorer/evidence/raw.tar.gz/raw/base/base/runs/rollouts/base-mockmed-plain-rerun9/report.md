status: saved

Triage encounter recorded for Jane Sample with note: 'Triage: knee pain, ice and rest, follow up in two weeks.'
