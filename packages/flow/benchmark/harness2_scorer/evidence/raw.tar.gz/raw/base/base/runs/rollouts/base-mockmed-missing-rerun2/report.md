status: stopped

Jane Sample's record is not visible on the current screen. Need to locate or open her record first.
