status: saved

Triage encounter recorded for Jane Sample with the note saved successfully.
