status: saved

Triage encounter recorded and saved successfully.
