status: saved

Triage encounter recorded successfully for Jane Sample.
