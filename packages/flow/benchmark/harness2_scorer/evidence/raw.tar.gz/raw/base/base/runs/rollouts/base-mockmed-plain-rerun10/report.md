status: saved

Triage encounter for Jane Sample has been recorded successfully.
