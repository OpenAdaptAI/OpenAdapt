status: saved

The Triage encounter for Jane Sample is recorded and saved.
