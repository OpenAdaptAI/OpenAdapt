status: saved

Triage encounter for Jane Sample recorded with note.
