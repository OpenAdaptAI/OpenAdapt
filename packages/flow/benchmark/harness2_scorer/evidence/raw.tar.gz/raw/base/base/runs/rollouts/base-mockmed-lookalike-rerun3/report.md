status: saved

Triage encounter recorded and saved for Jane Sample.
