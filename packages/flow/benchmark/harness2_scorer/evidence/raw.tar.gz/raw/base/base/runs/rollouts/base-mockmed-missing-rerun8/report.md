status: stopped

Unable to find or select patient Jane Sample on the current screen.
