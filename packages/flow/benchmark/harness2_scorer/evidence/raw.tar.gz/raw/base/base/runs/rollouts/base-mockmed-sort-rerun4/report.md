status: saved

Triage encounter successfully recorded for Jane Sample.
