status: stopped

Encounter recording process stopped as the data appears to be already saved.
