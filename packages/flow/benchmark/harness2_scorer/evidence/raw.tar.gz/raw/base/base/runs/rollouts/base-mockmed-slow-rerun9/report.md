status: saved

Recorded a Triage encounter for Jane Sample with the note and saved it.
