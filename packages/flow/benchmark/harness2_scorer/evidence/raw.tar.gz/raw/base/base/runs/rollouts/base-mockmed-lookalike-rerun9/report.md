status: saved

Triage encounter recorded successfully.
