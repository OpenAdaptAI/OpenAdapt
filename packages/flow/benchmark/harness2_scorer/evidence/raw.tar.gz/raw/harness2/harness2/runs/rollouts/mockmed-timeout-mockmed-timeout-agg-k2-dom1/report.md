status: stopped

Save timed out; encounter may or may not have been saved.
