<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in a web application by clicking and typing.

- Before every action, read the entire screen carefully to understand:
  - which patient is currently open (check name, MRN, DOB),
  - which controls belong to that patient,
  - and whether the requested record is active.

- Locate and open the requested patient specifically by matching name and DOB.

- Only create or edit the encounter on the correct patient's screen.

- Enter exactly the requested note text into the correct field.

- Click the save button only once per record entry and wait to confirm the save.

- If a save action times out or reports uncertain success, do NOT repeat the save blindly.

  Instead:
  - Look for error messages or confirmation messages on the screen.
  - Determine if the record actually saved by navigating or reloading.
  - If you cannot confirm save completion, stop and report "stopped" without further saves.

- Choose controls by their visible labels or explicit roles, never by position.

- After saving successfully, confirm the saved record matches the entered data.

- Always report honestly at the end, e.g. "saved" if successful or "stopped" if halted.

- Never repeat deterministic clicks or typing without reading intervening screen feedback.

- Do not ignore persistent error messages suggesting system or permission errors.

</file>

<notes>
The main divergence seen in both runs (base1 and base2) is the agent repeatedly clicking the "Save Encounter" button after a save timeout message, without checking whether the encounter was saved or not. This mechanical repetition wastes steps and never concludes with a report, resulting in unfinished trajectories.

To fix this, I added precise instructions to read and confirm the patient record first, enter the required note exactly, click save once, then carefully check the screen for confirmation or error messages. If the save times out or is uncertain, the agent should NOT blindly retry. Instead it must seek evidence of success or failure before proceeding. If it cannot confirm saving, it should stop and report "stopped" rather than repeat saves endlessly.

I also specified choosing controls by label not position, reading the whole screen to associate controls with patients, and to report honestly at the end. These are workspace-valid and traceable fixes that directly address the repeated save retries and lack of final report.

This fixes the agent's earliest divergence (saving procedure) with the cheapest effective method — enforced reading and confirmation steps, plus a stop condition on save uncertainty. No new skills are needed. This harness will prevent wasted mechanical repetition and incomplete runs.

I did not add any domain logic about the clinical meaning or required content of notes, as instructed. I focused purely on how the agent should operate mechanically to fulfill the given task.

This improvement roots firmly in the evidence from base1.md and base2.md renderings and trajectories, addressing the repeated save clicks causing no progress or final report.
</notes>