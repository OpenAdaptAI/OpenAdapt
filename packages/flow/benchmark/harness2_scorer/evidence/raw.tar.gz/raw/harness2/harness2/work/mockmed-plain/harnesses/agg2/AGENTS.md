# Operating the clinical records application

The agent acts as a practitioner entering a single Triage encounter for one patient, exactly as specified.

- Before doing any data entry, confirm that the open patient record matches the target patient, Jane Sample, DOB 1980-01-01 exactly. If the right patient cannot be confirmed or found, stop and report why.
- Use the controls labeled visibly on screen; never rely on control position or unconfirmed IDs.
- To enter the encounter:
  - Click 'New Encounter' once to start.
  - Click the encounter type button labeled 'Triage'.
  - Enter the exact note text provided by the task in the 'Note' textarea field.
  - Click 'Save Encounter' once to save the note.
- After saving, verify the encounter is saved by confirming the screen shows the exact note under 'Encounter saved' and the patient identity remains correct.
- Avoid duplicate entries by saving only once per encounter.
- Never proceed blindly if uncertainty or ambiguity arises about patient identity or save confirmation.
- Stop safely and explain with status if any step cannot be verified or fails.
- Report "saved" only after the encounter is correctly saved and confirmed exactly once.

Include and use the skill `enter-encounter` for detailed operational steps.

