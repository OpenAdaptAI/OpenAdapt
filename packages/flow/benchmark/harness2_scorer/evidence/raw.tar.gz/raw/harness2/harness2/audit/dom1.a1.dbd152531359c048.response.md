<file path="harness/AGENTS.md">
# Practitioner domain harness for clinical record entry

- ANALYTIC MOVE: Reconcile requested patient identity with open record.
  Input: Patient name, DOB, and identifiers from task; screen header and patient info.
  Result: Confirm patient on screen matches request exactly by name and DOB before write.

- ANALYTIC MOVE: Compare note content entered with task note.
  Input: Note text shown on screen, task note text.
  Result: Confirm exact text from task is present in note field before saving.

- ARTIFACT CONTRACT: A saved encounter must contain:
  - Patient identity (name, MRN, DOB) matching the requested record fully.
  - Encounter type selected as requested (Triage).
  - Note field text identical to the instructed note.
  - Single save action per encounter to establish record.

- DECISION RULE: Trigger saving encounter only if patient identity matches task data exactly and note content matches requested note exactly.
  - Evidence support: Screen title, patient demographics, note field content.
  - Conflicts: If patient on screen differs from requested, do not write; report stopped.
  - Uncertainty: If identity uncertain or multiple candidates, do not attempt write; stop and explain.

- DECISION RULE: Trigger stopping the task if patient record cannot be found matching the task input.
  - Evidence: No patient screen with exact name and DOB.
  - Provide reason for stopping.

- ENCODING: Knowledge of patient matching and note verification is encoded in always-on checks:
  - Check patient header text fields for exact match.
  - Check note field text for exact string match.
  - Confirm encounter type selection matches task input.
  - Detect a single save button click per encounter.
  - Avoid duplicate saves by recognizing saved status on screen.

- HARD RULES:
  1. Do not write to a record unless patient identity matches exactly.
  2. Do not submit twice for the same encounter.
  3. If the requested patient cannot be found or confirmed, stop safely and explain why.

- WORKSPACE FACTS:
  - Patient "Jane Sample" in this workspace has MRN "P1" and DOB "1980-01-01".
  - The patient screen's header shows "Jane Sample — MRN P1 — DOB 1980-01-01".
  - The Triage encounter requires selecting the 'Triage' button and entering the 'Note' textarea.
  - Saving is done by clicking 'Save Encounter' exactly once.
  - Successful save updates the patient screen with text starting "Encounter saved — Triage:" plus portion of note.

- PROCEDURE:
  1. Locate and open the patient record matching name "Jane Sample" and DOB "1980-01-01".
  2. Start a new encounter, select 'Triage' encounter type.
  3. Enter the exact note text given by the task: "Triage: knee pain, ice and rest, follow up in two weeks."
  4. Click 'Save Encounter' once.
  5. Confirm save success by detecting updated screen status.
  6. Stop and report "saved" when complete.

- STOP condition handling:
  - If patient record not found or mismatched identity, stop with a clear reason rather than risk wrong patient write.
  - If duplicate encounter detected, do not resubmit; stop safely.

</file>

<notes>
This edit anchors the practitioner's knowledge as analytic moves, artifact contracts, decision rules, and workspace facts explicitly to the workspace patient identity, encounter type, note content, and UI controls identified in the trajectories. It directly addresses the key failure modes observed in runs (writing on wrong patient, or multiple saves) by insisting on exact match of patient identity before writing and single save action only.

Each domain check references exact textual evidence seen on the screen from the provided runs (e.g., MRN P1, DOB 1980-01-01, Triage note text), so the agent does not have to rediscover or guess.

It adds clear stopping rules when the patient cannot be reliably identified, addressing the hard rule to never write on the wrong chart and being honest about failure.

The procedure stepwise clarifies what the agent must do and check, directly supporting accurate and safe completion for this task family.

This edit is motivated by a divergence moment: runs succeeded but the harness lacked these critical domain checks and workspace mappings, so adding them improves reliability for future tasks by compliance with practitioner knowledge.

The changes do not include any procedural details beyond what the practitioner needs to know; procedural mechanisms remain the agent's concern but are supported by these domain checks.

No invented standards or authorities are used, only confirmed workspace facts seen in the rollout observations and screen text.

No redundant or generic advice is added; rules are precise and grounded in the task's workspace evidence.

This succinct but rich domain harness provides a solid practitioner model for the autonomous agent.
</notes>