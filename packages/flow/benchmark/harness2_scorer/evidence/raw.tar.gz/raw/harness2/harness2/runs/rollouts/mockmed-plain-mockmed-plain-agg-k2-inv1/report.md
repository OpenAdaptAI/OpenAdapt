status: saved

Triage encounter recorded for Jane Sample with the specified note and confirmed on the screen.
