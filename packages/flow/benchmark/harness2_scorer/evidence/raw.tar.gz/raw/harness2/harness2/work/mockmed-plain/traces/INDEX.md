# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-plain-mockmed-plain-agg-k2-agg1](traces/mockmed-plain-mockmed-plain-agg-k2-agg1/trace.md) | mockmed/plain | agg1 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-base2](traces/mockmed-plain-mockmed-plain-agg-k2-base2/trace.md) | mockmed/plain | base2 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-dom1](traces/mockmed-plain-mockmed-plain-agg-k2-dom1/trace.md) | mockmed/plain | dom1 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-dom2](traces/mockmed-plain-mockmed-plain-agg-k2-dom2/trace.md) | mockmed/plain | dom2 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-inv1](traces/mockmed-plain-mockmed-plain-agg-k2-inv1/trace.md) | mockmed/plain | inv1 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-inv2](traces/mockmed-plain-mockmed-plain-agg-k2-inv2/trace.md) | mockmed/plain | inv2 | verified | 1.0 |  |  |
| [mockmed-plain-mockmed-plain-agg-k2-agg2](traces/mockmed-plain-mockmed-plain-agg-k2-agg2/trace.md) | mockmed/plain | agg2 | reconciliation_required | -1.0 |  | yes |
| [mockmed-plain-mockmed-plain-agg-k2-base1](traces/mockmed-plain-mockmed-plain-agg-k2-base1/trace.md) | mockmed/plain | base1 | wrong_effect | -1.0 |  | yes |
