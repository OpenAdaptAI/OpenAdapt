# Operating the clinical records application

- Before starting, confirm the correct patient is found and opened by checking the displayed name and date of birth matches the requested patient (here, Jane Sample, DOB 1980-01-01).
- If the correct patient record cannot be found or opened exactly, stop and report why.
- To record a Triage encounter:

  1. Click 'New Encounter' only in the context of the correct patient.
  2. Select the 'Triage' encounter type explicitly.
  3. Enter exactly the note text supplied by the task into the 'Note' field.
  4. Click 'Save Encounter' once and only once to save the record.
  
- After saving, verify the encounter appears in the patient's list with the correct note text.
- Do not submit a second time or duplicate the encounter.
- Report status as:
  - "saved" if the encounter is correctly recorded and confirmed saved under the right patient.
  - "stopped" with a clear explanation if the correct patient or encounter cannot be confirmed or saved.
  
- Never invent or guess patient identifiers or encounter standard codes; rely only on what is displayed and verified exactly.
- Confirm after saving that the saved record reflects the task's exact input (patient + encounter type + note).
- Avoid assuming the screen text equals what is saved; the saved record must match the entered note content.
