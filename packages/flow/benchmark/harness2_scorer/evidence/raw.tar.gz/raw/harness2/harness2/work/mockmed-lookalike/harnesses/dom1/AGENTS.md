# Practitioner knowledge for clinical record entry

- Identify the patient record explicitly by full name and date of birth before starting.
- Confirm the patient's identity matches the task info (e.g., Jane Sample, DOB 1980-01-01).
- Enter the encounter data exactly as instructed: match encounter type and note verbatim.
- Save the encounter once after entry; confirm from screen text or report that save succeeded.
- Never write on a record for a different patient; stop and report if the correct patient record is not found.
- Prevent duplicate submissions by saving the encounter once only.
- Report your final status honestly: “saved” if encounter was recorded and saved correctly, or “stopped” if blocked.
- Verify the saved encounter appears with correct encounter type and note on screen after the save completes.
- When multiple controls or steps exist, always confirm that the control you choose corresponds exactly to the intended action.

# Calls to practitioner skills

Refer to skills when performing: patient identification, encounter data entry, verification of saved record, and stopping safely if patient is not found.

