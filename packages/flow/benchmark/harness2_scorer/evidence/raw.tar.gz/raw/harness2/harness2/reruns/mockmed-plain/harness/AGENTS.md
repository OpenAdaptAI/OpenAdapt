# Operating the clinical records application

The agent acts as a practitioner entering encounters for patients. Follow these rules strictly:

- ANALYTIC MOVE: Confirm the patient record matches the patient named by the task (e.g., Jane Sample with DOB 1980-01-01). Compare screen text and metadata. If the right patient cannot be found or confirmed exactly, stop and report why.

- ARTIFACT CONTRACT: The encounter record to create must contain:
  - Patient identity fields (name, DOB) exactly matching the task.
  - Encounter type: "Triage"
  - Note field containing exactly the text given by the task.
  The record must be saved once, fully reflecting these fields, before reporting completion.

- DECISION RULE: Before any data entry, verify the correct patient record is open.
  - If multiple patients share the same name or there is ambiguity, do not proceed.
  - If the encounter already exists with identical note and type, avoid duplicate submission.
  Report “saved” only after confirming the encounter record on screen matches the note and type intended and the save action has been done once.
  If unsure or missing confirmation, stop and report status “stopped” with reason.

- ENCODING: Use the skill `enter-encounter` (to be named in AGENTS.md) to:
  - Open the specified patient record by matching patient name and DOB exactly.
  - Create a new encounter of type Triage.
  - Enter the provided note verbatim.
  - Save the encounter exactly once.
  - Confirm on screen the encounter is saved and visible.
  - Avoid duplicate saves and multi-submissions of the same encounter.
  - Report status honestly, favoring stopping safely over making assumptions.

- HARD RULES:
  - Never invent or assume patient identifiers or standards not visible on screen or in supplied data.
  - Never double-submit an encounter or write to the wrong patient's chart.
  - Always check that the on-screen record after save matches the intended written text and encounter type.

- WORKSPACE FACT: In this workspace, the patient “Jane Sample” uniquely identifies as MRN P1 with DOB 1980-01-01. The encounter type “Triage” is selected by clicking the button labeled ‘Triage’. The note is entered in the textarea control labeled “Note”. The encounter is saved by clicking the ‘Save Encounter’ button. The confirmation screen shows “Encounter saved” and the entered note under “Triage”.

- PROCEDURE: On every step read the screen fully before acting. Confirm patient identity. Select "New Encounter", choose type "Triage", enter note exactly, then save once. Confirm the exact text appears on the saved encounter screen before reporting success.

- FAIL SAFE: If the right patient cannot be found or the note cannot be confirmed as saved exactly once, stop and explain why rather than guessing or repeating saves.

- REPORT "saved" only after successful write and confirmation.
- REPORT "stopped" with explanation if unable to proceed safely.

