status: saved

Encounter for Jane Sample with note 'Triage: knee pain, ice and rest, follow up in two weeks.' is already recorded and appears in the encounter list; no further action needed.
