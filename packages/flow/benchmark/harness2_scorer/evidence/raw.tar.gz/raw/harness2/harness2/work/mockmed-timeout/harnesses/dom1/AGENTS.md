# Operating the clinical records application

- Before starting, locate and open the correct patient's record exactly by matching full name and date of birth.
- If the patient record cannot be found unambiguously, stop and report "stopped: patient not found".
- Create a new encounter only under the correct patient's record.
- Select the encounter type as instructed (e.g., 'Triage').
- Enter the note text exactly as provided; do not alter or add information.
- Save the encounter exactly once after entering the required information.
- If the save action times out or indicates uncertain success, do NOT retry saving repeatedly; instead, stop and report "stopped: save status uncertain".
- After saving, verify that the encounter appears saved (e.g., is listed under encounters).
- Report "saved" only if you confirm the encounter is successfully recorded in the patient's data.
- Avoid writing or saving on any patient other than the specified target.
- Do not attempt to create duplicate encounters for the same task.
- Always report your final status clearly: "saved", or "stopped: reason".

