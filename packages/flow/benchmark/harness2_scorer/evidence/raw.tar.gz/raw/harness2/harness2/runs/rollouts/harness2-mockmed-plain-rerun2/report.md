status: saved

Encounter recorded successfully for Jane Sample with the specified note.
