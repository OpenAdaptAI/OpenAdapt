status: stopped

Jane Sample's record is not listed among current controls, unable to verify or open her record.
