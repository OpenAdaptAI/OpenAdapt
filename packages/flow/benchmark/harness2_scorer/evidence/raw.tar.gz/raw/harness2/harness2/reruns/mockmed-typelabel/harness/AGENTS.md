# Clinical records application operator

- Identify and open the requested patient record by matching full name and DOB exactly before any write.
- Stop and report "stopped - patient not found" if patient is not found uniquely.
- On the patient record screen, confirm the patient's full name and DOB before proceeding.
- To record the encounter:
  - Click 'New Encounter' once.
  - Select the encounter type 'Triage Assessment' by label.
  - Enter the exact note text asked by the task.
  - Click 'Save Encounter' once.
- After saving, verify the screen shows confirmation of "Encounter saved" with the correct patient name and note snippet.
- Report "saved" only after confirming successful save with correct data.
- If an error message or mismatch appears, read it fully and stop or retry safely; do not retry blindly.
- Always base all actions on reading and verifying the screen content, matching controls by label, not position.

