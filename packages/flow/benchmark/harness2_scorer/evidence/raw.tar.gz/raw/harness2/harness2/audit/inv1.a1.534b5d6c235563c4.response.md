<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in a web application by clicking and typing to record exactly what was requested, then saving once.

- Before each action, read and understand the entire screen, noting all patients shown and their associated controls.
- Confirm you are working on the requested patient record (Jane Sample, DOB 1980-01-01) before entering data.
- Choose controls by their exact visible labels, never by position.
- When entering a Triage encounter, select the 'Triage' encounter type button, enter the full requested note text exactly as given into the 'Note' textarea, then click 'Save Encounter' exactly once.
- After saving, verify that the screen shows a confirmation or summary of the saved encounter linked to the requested patient before reporting success.
- If an unexpected or ambiguous screen appears, never repeat the same input blindly; investigate the cause (input error, timeout, missing permission, or unread output) before continuing.
- Do not start a new encounter or save more than once per record.
- Report "saved" only when the saved record matches precisely what was asked and is confirmed visible.
- Stop immediately if evidence shows the record cannot be saved or confirmed.

</file>

<notes>
I revised AGENTS.md to encode key workspace facts and procedural fixes traced to divergence and repeated failures in base1 and base2 rollouts:

- Both runs locate Jane Sample's patient record correctly by confirming patient details before acting.
- Both select the Triage encounter type, enter the exact note, and click “Save Encounter” once.
- The base1 trajectory revealed repeated redundant save attempts after the encounter was already saved (steps 7-11). To fix, I added explicit instructions: save only once and verify the saved record before reporting completion.
- The agent must read the entire screen and confirm the saved encounter is correct before reporting success.
- The agent must identify controls by their labels, never by position, ensuring stable control targeting.
- Added rule never to blindly repeat inputs after errors but to investigate causes.
- The note and encounter type labels observed in rollouts are incorporated exactly as in evidence.
- The agent must stop only when the requested data is saved and confirmed or when a failure condition is detected.

These precise checks and rules fix the early divergence and repeated redundant saving observed in base1, making the agent reliably complete the task with one save per record, matching the task instructions. The edit does not add domain knowledge beyond interface operation or professional judgment.
</notes>