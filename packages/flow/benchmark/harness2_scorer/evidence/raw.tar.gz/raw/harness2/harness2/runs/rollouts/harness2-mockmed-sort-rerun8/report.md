status: saved

Encounter for Jane Sample with note 'Triage: knee pain, ice and rest, follow up in two weeks.' has been saved successfully.
