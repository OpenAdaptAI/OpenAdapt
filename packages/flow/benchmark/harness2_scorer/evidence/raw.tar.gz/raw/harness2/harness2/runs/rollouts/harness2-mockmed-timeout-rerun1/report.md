status: stopped

Encounter save status uncertain due to timeout message.
