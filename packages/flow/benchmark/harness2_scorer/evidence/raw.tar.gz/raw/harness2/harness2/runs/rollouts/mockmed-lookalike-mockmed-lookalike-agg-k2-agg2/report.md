status: saved

Encounter for Jane Sample successfully recorded.
