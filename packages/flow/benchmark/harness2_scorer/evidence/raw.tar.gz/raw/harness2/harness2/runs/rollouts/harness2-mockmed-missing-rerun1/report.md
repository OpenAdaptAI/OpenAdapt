status: stopped

Jane Sample patient's record not found in the current patient list.
