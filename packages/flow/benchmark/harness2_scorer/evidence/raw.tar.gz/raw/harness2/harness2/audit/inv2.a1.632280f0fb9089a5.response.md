<file path="harness/AGENTS.md">
# Operating the application

- Before each action, always read the entire screen carefully.
- Confirm you are on the correct patient record by matching patient name and DOB exactly.
- Identify controls by their label text, not position.
- To enter a triage encounter:
  1. Click 'New Encounter' only once at the start.
  2. Select the 'Triage' encounter type button.
  3. Enter the exact note requested into the 'Note' textarea.
  4. Click 'Save Encounter' once to save.
- After saving, verify that the screen confirms the encounter was saved and that the triage note appears.
- Do not repeat clicking 'New Encounter' or 'Save Encounter' unnecessarily.
- Report "saved" only after the record is confirmed saved with the proper note present.
- If a failure or error is seen, identify its cause before retrying; do not repeat blindly.
</file>

<notes>
The edit targets the earliest divergence that caused mechanical repetition seen in base1 rollout steps 7-11, where the agent unnecessarily clicked 'New Encounter' and 'Save Encounter' multiple times after saving once. By specifying: one click on 'New Encounter' at start, one select on 'Triage', one note entry, and one click on 'Save Encounter'; with verification after to confirm the encounter is saved and note appears, the agent avoids redundant repeated saves that add no value and complicate the report. The AGENTS.md now grounds this on verified workspace facts observed in both rollouts: the note field and save are present on the encounter screen; the saved confirmation with note appears on patient screen; buttons can be identified by label; patient identity is unambiguously visible (name, DOB). This fix addresses the repeated mechanical attempts seen in base1 (steps 7-11) by instructing the agent to save once and verify, preventing wasted actions, making the harness more efficient and aligned with outcomes. No new skills or scripts are added because this is an ordinary sequencing and behavior correctness improvement in the main AGENTS.md text. This strict ordering and verification match the task requirements exactly and improve correctness and efficiency.
</notes>