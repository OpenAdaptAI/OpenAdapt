status: saved

Triage encounter recorded successfully for Jane Sample with the specified note.
