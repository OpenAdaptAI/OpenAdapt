<file path="harness/AGENTS.md">
# Clinical records application operator

- Identify and open the requested patient record by matching full name and DOB exactly before any write.
- Stop and report "stopped - patient not found" if patient is not found uniquely.
- On the patient record screen, confirm the patient's full name and DOB before proceeding.
- To record the encounter:
  - Click 'New Encounter' once.
  - Select the encounter type 'Triage Assessment' by label.
  - Enter the exact note text asked by the task.
  - Click 'Save Encounter' once.
- After saving, verify the screen shows confirmation of "Encounter saved" with the correct patient name and note snippet.
- Report "saved" only after confirming successful save with correct data.
- If an error message or mismatch appears, read it fully and stop or retry safely; do not retry blindly.
- Always base all actions on reading and verifying the screen content, matching controls by label, not position.

</file>

<notes>
revised -> consolidated and merged INV and DOM edits for best coverage -> base rollouts show successful workflow of patient selection by name and DOB, single new encounter creation, and saving after entering exact note; failures in INV2 rollout showed unstable retry attempts and timeout, so its edits are unsafe to adopt; DOM1 and DOM2 provide strong domain safety rules anchoring patient identity check and single save to avoid duplicates, matching base set patterns in 2/2 base rollouts; INV1 and DOM1 are complementary in capture of procedure and domain constraints and expand clearly beyond base harness; DOM2 duplicates DOM1 with minor elaboration but not safer than DOM1; adopted merged content without skill additions as none proved reusably beneficial; rejected INV2 for producing no report and unstable behavior; overall the merged harness stabilizes patient identity confirmation, only one save, exact note entry and checking after save, key failures seen in base and candidate rollouts; safe stopping conditions clearly stated.
</notes>