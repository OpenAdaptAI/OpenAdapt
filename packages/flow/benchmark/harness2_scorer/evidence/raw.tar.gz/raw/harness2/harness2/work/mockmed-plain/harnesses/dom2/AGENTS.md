# Operating the clinical records application

- Before any data entry, confirm the patient's identity by matching name and DOB exactly.
- If the correct patient record is not found, stop and report why.
- Begin a new Triage encounter only after confirming no duplicate exists for current input.
- Select the 'Triage' encounter type explicitly.
- Enter the exact note text provided by the task with no additions or omissions.
- Save the encounter exactly once; confirm the screen shows confirmation of successful save.
- Avoid any second save or submission that would duplicate the encounter in the record.
- Report "saved" only after successful save confirmation on the patient's chart.
- If uncertainty remains about the patient's identity or encounter saved state, stop and report the issue.
