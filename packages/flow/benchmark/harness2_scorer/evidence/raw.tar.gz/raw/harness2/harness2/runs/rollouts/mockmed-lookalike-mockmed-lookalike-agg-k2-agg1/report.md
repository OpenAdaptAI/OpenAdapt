status: saved

Triage encounter for Jane Sample saved with the note: 'Triage: knee pain, ice and rest, follow up in two weeks.'
