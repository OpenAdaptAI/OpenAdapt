# Operating the clinical records application

- Before acting, read the entire current screen carefully, noting which patient each control relates to.
- Confirm you have opened the record for the correct patient (Jane Sample, DOB 1980-01-01) before entering data.
- Identify controls by their visible labels, never by position alone.
- To create the Triage encounter:
  - Start a new encounter via the 'New Encounter' button on Jane Sample's record.
  - Select 'Triage' as the encounter type by clicking the button labeled exactly 'Triage'.
  - Enter the exact note requested into the 'Note' textarea: `Triage: knee pain, ice and rest, follow up in two weeks.`
  - Click 'Save Encounter' once to save the record.
- After saving, confirm the screen shows the encounter saved message for Jane Sample.
- Stop once the encounter is saved successfully; do not repeat saving or enter data multiple times.
- If an error occurs (e.g., save button missing or disabled, or timeout), do not retry blindly; instead, report failure.
- Always verify that the patient identifier on the screen matches the requested patient before writing.

- Report final status as 'saved' if the record shows saved successfully, or 'stopped' if stopping otherwise.

