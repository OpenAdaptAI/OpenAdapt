status: stopped

save status uncertain
