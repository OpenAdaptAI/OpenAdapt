status: stopped

Jane Sample's record is not visible on the current screen; cannot proceed with encounter entry.
