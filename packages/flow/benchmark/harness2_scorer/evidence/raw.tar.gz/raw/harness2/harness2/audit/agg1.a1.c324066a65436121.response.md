<file path="harness/AGENTS.md">
# Operating the clinical records application

- Locate and open the correct patient's record exactly by matching the full name and date of birth from the task.
- If the patient record cannot be found exactly (both name and DOB), stop and report "stopped: patient not found".
- Create a new encounter only under the correct patient.
- Select the encounter type as requested (e.g. 'Triage').
- Enter the note text exactly as requested; do not add or omit details.
- Click the Save button exactly once after entering all required data.
- After saving, read the screen carefully to confirm that the save succeeded.
- If the screen shows a "Save timed out" or any ambiguous save status, do NOT retry saving repeatedly.
  Instead, stop and report "stopped: save status uncertain".
- Avoid duplicate encounter creation or entries to the wrong patient.
- Always produce a final clear report: "saved" if successful, or "stopped: reason" if interrupted.
</file>

<notes>
revised -> combined domain rules on patient identification, exact note entry, single save, save status interpretation, and final reporting into AGENTS.md, merging dom1 and dom2 domain focuses with inv1 and inv2 operational clarity -> all 4 candidate harnesses emphasize confirming patient by full name + DOB, entering exact note, clicking save once, and stopping on save timeout without retrying; base harness is too minimal and produces no report; base rollouts repeatedly click save after timeout leading to failure; inv candidates add mechanical rules on control selection and stop-on-timeout behavior; dom candidates add practitioner domain knowledge re patient confirmation and save contract; merged to cover all necessary coverage in a single clear agent guide without skills or scripting; reject repeated saves to avoid failures found in base rollouts (2/2 base failed this); reject any harness from inv1/inv2 due to their repeated save attempts causing incomplete runs; reject dom1/dom2 wholesale as they are very similar and more verbose; merge concise, precise instructions from all candidates that avoid repeated saves and require precise patient identification and final reporting; evidence: repeated save clicks in 2/2 base fail; all 4 candidates do exactly one save and stop on timeout; produced reports from candidates confirm stopping; merged rules unify that into one short, explicit harness.
kept -> no skills added since all logic fits cleanly into AGENTS.md without overcomplexity or need for reusable procedures.
</notes>