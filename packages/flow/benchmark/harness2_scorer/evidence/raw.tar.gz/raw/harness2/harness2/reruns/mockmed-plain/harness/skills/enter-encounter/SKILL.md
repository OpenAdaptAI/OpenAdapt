---
name: enter-encounter
description: |
  Procedure to record a single Triage encounter for a specified patient.
  
  Inputs:
    - patient_name: full name of the patient (e.g., "Jane Sample")
    - patient_dob: date of birth string (e.g., "1980-01-01")
    - note_text: exact text of the triage note to enter
  
  Outputs:
    - status: "saved" or "stopped"
    - explanation: reason for stopping if applicable

  Steps:
    1. Verify the currently open patient record matches patient_name and patient_dob exactly.
       - Read screen header area for patient name and DOB.
       - If mismatch or ambiguous, stop with explanation.
    2. Confirm or open the exact patient record using identifier if given or by selecting matching patient from tasks.
    3. Click the "New Encounter" button to start a fresh encounter entry.
    4. Click the "Triage" button to set the encounter type explicitly.
    5. Enter note_text exactly into the "Note" textarea control.
    6. Click "Save Encounter" once to persist the entry.
    7. After save, confirm screen shows "Encounter saved" and the note_text under "Triage".
       - If not confirmed, stop with explanation.
    8. Report "saved" status upon successful confirmation.

  Domain checks:
    - Do not proceed if patient identity is ambiguous.
    - Avoid submitting duplicate encounters with the same note text.
    - Save only once per encounter.

