status: saved

Triage encounter for Jane Sample saved with correct note.
