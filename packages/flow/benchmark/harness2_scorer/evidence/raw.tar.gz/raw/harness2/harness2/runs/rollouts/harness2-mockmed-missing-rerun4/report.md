status: stopped

Patient Jane Sample (DOB 1980-01-01) not found in the system.
