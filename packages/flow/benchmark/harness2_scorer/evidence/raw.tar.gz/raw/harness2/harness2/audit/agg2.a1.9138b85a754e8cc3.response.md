<file path="harness/AGENTS.md">
# Operating the clinical records application for exact patient encounters

- Before acting, always read and interpret the entire screen carefully.
- Verify the open patient record matches exactly the requested patient by name "Jane Sample" and DOB "1980-01-01".
- Find and select the patient record by clicking the 'Open' button in the patient's task row.
- Start a new encounter by clicking the 'New Encounter' button on the patient screen.
- Select the encounter type by clicking the button labeled exactly 'Triage'.
- Enter the exact note text "Triage: knee pain, ice and rest, follow up in two weeks." in the textarea labeled 'Note'.
- Click the single 'Save Encounter' button exactly once when the note and encounter type are correct.
- Confirm save success by detecting the updated screen message showing "Encounter saved" for Jane Sample with the entered note.
- Stop and report 'saved' only after confirming the record saved correctly.
- If patient record cannot be found or does not match exactly, or if expected controls do not appear, stop and report 'stopped' with reason.
- Never write to a patient record unless the patient identity exactly matches the task request.
- Avoid duplicate saving of the same encounter; do not save if identical encounter already exists.

</file>

<notes>
kept -> base harness minimal instructions for task family, no evidence favors no changes over improvements
revised -> inv1 -> All key invariant workflow steps and data integrity checks now explicit: patient exact match (name+DOB), control selection by label, note exact match, single save, confirm save, stop on failure; supported by inv1 rollout moments (steps 0-7) that show consistent correct behavior
revised -> inv2 -> Clarifications and explicit patient identity check, save-once rule, no retries on error, matching rollout steps 0-7; supports stable, unambiguous operation
revised -> dom1 -> Practitioner domain knowledge anchoring clinical and workspace facts, workflow analytic moves, decision rules preventing wrong patient writes or duplicate saves, and clear stopping criteria; directly motivated by failures observed or inferred, and rollout steps 0-7 that show correct data, patient identity, and save semantics
revised -> dom2 -> Overlap with dom1 in patient and encounter checks, explicit duplicate encounter detection, workspace facts, and decision logic; supports safe operation and stopping if patient missing; rollout steps 0-7 strongly evidence this procedure
dropped -> no evidence supports including both dom1 and dom2 whole; merged domain knowledge from both for coverage and specificity while avoiding redundancy; no explicit skills required as the task and runs show successful end-to-end procedure without modular skills
merged -> all candidate harnesses + base to produce a harness that fully incorporates workspace patient identity and encounter artifact facts, analytic moves, decision rules, and practical stepwise instructions based on repeated rollout successes in both base and candidates
no rollout associated with any candidate or base produced a run with no delivered result — all safely delivered
</notes>