status: saved

The encounter for Jane Sample with note 'Triage: knee pain, ice and rest, follow up in two weeks.' has been recorded successfully.
