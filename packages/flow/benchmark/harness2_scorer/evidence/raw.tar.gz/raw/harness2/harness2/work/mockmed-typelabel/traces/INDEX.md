# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-typelabel-mockmed-typelabel-agg-k2-agg1](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-agg1/trace.md) | mockmed/typelabel | agg1 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-agg2](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-agg2/trace.md) | mockmed/typelabel | agg2 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-base1](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-base1/trace.md) | mockmed/typelabel | base1 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-base2](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-base2/trace.md) | mockmed/typelabel | base2 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-dom1](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-dom1/trace.md) | mockmed/typelabel | dom1 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-inv1](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-inv1/trace.md) | mockmed/typelabel | inv1 | verified | 1.0 |  |  |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-dom2](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-dom2/trace.md) | mockmed/typelabel | dom2 | wrong_effect | -1.0 |  | yes |
| [mockmed-typelabel-mockmed-typelabel-agg-k2-inv2](traces/mockmed-typelabel-mockmed-typelabel-agg-k2-inv2/trace.md) | mockmed/typelabel | inv2 | reconciliation_required | -1.0 |  | yes |
