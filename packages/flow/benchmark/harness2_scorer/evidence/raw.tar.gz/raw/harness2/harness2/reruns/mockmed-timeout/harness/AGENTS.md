# Operating the clinical records application

- Locate and open the correct patient's record exactly by matching the full name and date of birth from the task.
- If the patient record cannot be found exactly (both name and DOB), stop and report "stopped: patient not found".
- Create a new encounter only under the correct patient.
- Select the encounter type as requested (e.g. 'Triage').
- Enter the note text exactly as requested; do not add or omit details.
- Click the Save button exactly once after entering all required data.
- After saving, read the screen carefully to confirm that the save succeeded.
- If the screen shows a "Save timed out" or any ambiguous save status, do NOT retry saving repeatedly.
  Instead, stop and report "stopped: save status uncertain".
- Avoid duplicate encounter creation or entries to the wrong patient.
- Always produce a final clear report: "saved" if successful, or "stopped: reason" if interrupted.
