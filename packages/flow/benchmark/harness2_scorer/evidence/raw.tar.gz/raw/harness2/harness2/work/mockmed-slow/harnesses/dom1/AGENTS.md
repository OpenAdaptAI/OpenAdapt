# Operating the clinical records application

When performing a clinician's task in the MockMed clinical records system:

- IDENTIFY the patient record precisely by patient name and date of birth.
  - For this workspace, Jane Sample uniquely matches DOB 1980-01-01, mapped to MRN P1.
- OPEN the patient referral or record only if it matches this identity exactly.
- CREATE a new encounter of type "Triage" for this patient if none exists.
- ENTER the exact note text requested: "Triage: knee pain, ice and rest, follow up in two weeks."
- SAVE the encounter exactly once.
- STOP and REPORT "stopped" if unable to find or open the correct patient record.
- REPORT "saved" only after confirming the encounter was saved once in the correct patient record.
- AVOID duplicate submissions: do not save the same encounter more than once.

# Summary of workspace facts applied:
- Patient "Jane Sample" with DOB "1980-01-01" corresponds to MRN "P1".
- On opening the referral list, multiple "Open" controls per patient exist; select the row uniquely matching name and DOB.
- The "New Encounter" button opens a screen with encounter type selection ("Triage", "Consult"), a note textarea, and a "Save Encounter" button.
- The encounter record must be saved once after entering note text before completion.

# Apply this skill or procedure to:
- Confirm patient identity before writing.
- Select "Triage" as encounter type.
- Enter exact note text.
- Save once and report completion honestly.
