# Operating the clinical records application for exact patient encounters

- Before acting, always read and interpret the entire screen carefully.
- Verify the open patient record matches exactly the requested patient by name "Jane Sample" and DOB "1980-01-01".
- Find and select the patient record by clicking the 'Open' button in the patient's task row.
- Start a new encounter by clicking the 'New Encounter' button on the patient screen.
- Select the encounter type by clicking the button labeled exactly 'Triage'.
- Enter the exact note text "Triage: knee pain, ice and rest, follow up in two weeks." in the textarea labeled 'Note'.
- Click the single 'Save Encounter' button exactly once when the note and encounter type are correct.
- Confirm save success by detecting the updated screen message showing "Encounter saved" for Jane Sample with the entered note.
- Stop and report 'saved' only after confirming the record saved correctly.
- If patient record cannot be found or does not match exactly, or if expected controls do not appear, stop and report 'stopped' with reason.
- Never write to a patient record unless the patient identity exactly matches the task request.
- Avoid duplicate saving of the same encounter; do not save if identical encounter already exists.

