# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-timeout-mockmed-timeout-agg-k2-agg1](traces/mockmed-timeout-mockmed-timeout-agg-k2-agg1/trace.md) | mockmed/timeout | agg1 | reconciliation_required | - |  |  |
| [mockmed-timeout-mockmed-timeout-agg-k2-agg2](traces/mockmed-timeout-mockmed-timeout-agg-k2-agg2/trace.md) | mockmed/timeout | agg2 | reconciliation_required | - |  |  |
| [mockmed-timeout-mockmed-timeout-agg-k2-dom1](traces/mockmed-timeout-mockmed-timeout-agg-k2-dom1/trace.md) | mockmed/timeout | dom1 | reconciliation_required | - |  |  |
| [mockmed-timeout-mockmed-timeout-agg-k2-dom2](traces/mockmed-timeout-mockmed-timeout-agg-k2-dom2/trace.md) | mockmed/timeout | dom2 | reconciliation_required | - |  |  |
| [mockmed-timeout-mockmed-timeout-agg-k2-base1](traces/mockmed-timeout-mockmed-timeout-agg-k2-base1/trace.md) | mockmed/timeout | base1 | reconciliation_required | -1.0 |  | yes |
| [mockmed-timeout-mockmed-timeout-agg-k2-base2](traces/mockmed-timeout-mockmed-timeout-agg-k2-base2/trace.md) | mockmed/timeout | base2 | reconciliation_required | -1.0 |  | yes |
| [mockmed-timeout-mockmed-timeout-agg-k2-inv1](traces/mockmed-timeout-mockmed-timeout-agg-k2-inv1/trace.md) | mockmed/timeout | inv1 | reconciliation_required | -1.0 |  | yes |
| [mockmed-timeout-mockmed-timeout-agg-k2-inv2](traces/mockmed-timeout-mockmed-timeout-agg-k2-inv2/trace.md) | mockmed/timeout | inv2 | reconciliation_required | -1.0 |  | yes |
