status: saved

Triage encounter for Jane Sample saved successfully with the correct note.
