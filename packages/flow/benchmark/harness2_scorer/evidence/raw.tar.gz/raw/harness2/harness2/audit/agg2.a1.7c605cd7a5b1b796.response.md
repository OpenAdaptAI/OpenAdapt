<file path="harness/AGENTS.md">
# Operating the clinical records application for Triage encounter

- Identify the patient by name "Jane Sample" and date of birth "1980-01-01" exactly.
- Open the referral or patient record only if it matches this identity.
- Avoid clicking 'Open' repeatedly: after one successful click of 'Open' for Jane Sample, do not retry if timeout occurs; proceed instead.
- On the patient's page, click "New Encounter" once to start a new encounter.
- If clicking "New Encounter" times out, do not retry blindly; instead, click the "Triage" button directly to select the encounter type.
- Enter exactly this note in the note field:  
  "Triage: knee pain, ice and rest, follow up in two weeks."
- Save the encounter once by clicking "Save Encounter".
- Confirm the correct note was saved by reading the screen before reporting.
- Report "saved" only after a confirmed successful save.
- If unable to find or open the correct patient, or to reach the Triage encounter screen, stop and report "stopped".
- Always choose controls by their exact labels, not by position.
- Read the screen carefully before each action and avoid mechanical repetition of clicks that trigger timeouts.

</file>

<notes>
dropped -> base harness AGENTS.md -> base rollouts 2/2 showed repeated redundant clicks and no save nor report, hence base too minimal
kept|revised -> dom1 candidate AGENTS.md -> precisely encodes patient identity, avoids duplicate clicks, controls workspace facts, explicit stop and report; matches steps 9-13 base rollouts timeout and no report failures
kept|revised -> inv1 candidate AGENTS.md -> handles timeout on "Open" and "New Encounter" click retries by fallback to "Triage" click; matches base steps 9-10 and 12 timeout-on-click pattern preventing completion
kept|revised -> inv2 candidate AGENTS.md -> emphasizes stopping mechanical repetition and detailed screen reading after timeout; matches base timeout clicks and no final reporting
dropped|not adopted -> dom2 candidate AGENTS.md -> very close to dom1, but weaker workspace facts anchoring and less specificity on MRN and controls; less clear fallback on retries
dropped|not adopted -> inv2 candidate AGENTS.md -> repetition of concepts in inv1, less detail on fallback strategy than inv1
synthesis: merge dom1 domain precision and workspace facts with inv1 robust handling of repeated timeout clicks and fallback to "Triage" button, plus stop/report discipline from inv2; omit dom2 repetition and lower detail; omit base minimal

The final harness balances domain precise patient identity and workspace steps with procedural robustness to handle mechanical failures seen in all base rollouts, ensuring one save and one report "saved" upon verified successful record. It avoids infinite retries or no output.

No skills files added as none supplied or needed.

</notes>