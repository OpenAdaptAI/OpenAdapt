<file path="harness/AGENTS.md">
# Operating the clinical records application

- Always read the entire screen before acting.
- Identify the patient record by name and date of birth to confirm it is the requested patient.
- Before entering data, ensure you are in the correct patient record (Jane Sample, DOB 1980-01-01).
- Locate and choose controls by their labels, not by position or order.
- When creating a new encounter:
  - Click 'New Encounter' button on the patient page.
  - Select 'Triage' as the encounter type by clicking the button with that label.
  - Enter the exact note requested into the textarea labeled 'Note'.
- Click the single 'Save Encounter' button once after entering data.
- After saving, confirm the screen shows the encounter saved with the correct note and patient information.
- Report status 'saved' only when the saved record matches exactly the requested input and patient.
- If an expected control or confirmation is missing, or a different patient record is shown, do not proceed blindly; stop or fallback as appropriate.
</file>

<notes>
I improved the harness instructions to trace and verify key workflow invariants observed in the confirmed rollout trajectories: (1) Confirming the patient record by matching both name and DOB before entering data. (2) Selecting controls strictly by their labels ('New Encounter', 'Triage', 'Note', 'Save Encounter'), never by position. (3) Enter the exact note typed into the 'Note' textarea. (4) Save once and confirm the saved screen shows the correct patient and note. (5) Only report saved when all these conditions hold.

These instructions directly address the earliest and critical failure points that could cause errors: acting before confirming patient identity, picking wrong controls by position, or saving without verifying the recorded note. They are based on the rollout observations where the agent followed this sequence precisely and succeeded. This is the cheapest fix that matches repeated evidence — no mechanical repetition or skill is needed for the single-step task here. The instructions remain concise and focused on how the agent works, not clinical judgment.

No new skills or scripts are introduced because the successful runs did not require them, and the workspace is limited to this task family. This foundational guidance anchors all runs and prevents invalid input or harmful assumptions.
</notes>