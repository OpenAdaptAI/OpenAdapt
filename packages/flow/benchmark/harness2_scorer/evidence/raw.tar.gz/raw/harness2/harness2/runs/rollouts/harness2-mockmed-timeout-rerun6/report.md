status: stopped

Save status uncertain
