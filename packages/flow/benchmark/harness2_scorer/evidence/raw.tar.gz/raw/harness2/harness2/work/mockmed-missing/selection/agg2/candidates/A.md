<!-- candidate A: 456 chars, 18 lines. COMPLETE -- nothing trimmed. Navigate with grep/offsets; evaluating a candidate means opening the part that determines whether it works.
-->
## The agent's report

status: stopped

Jane Sample is not visible in the current patient list.

## The last screen it saw

SCREEN (#tasks):
MockMed Clinical demo — all data is fake
Referral Tasks
Patient	Reason	Priority	Action
Alex Testcase	Cardiology follow-up	Medium	Open
Sam Specimen	Dermatology consult	Low	Open

CONTROLS:
[1] button 'Open' (row: Alex Testcase Cardiology follow-up Medium)
[2] button 'Open' (row: Sam Specimen Dermatology consult Low)