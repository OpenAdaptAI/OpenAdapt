# Practitioner domain harness for clinical record entry

- ANALYTIC MOVE: Reconcile requested patient identity with open record.
  Input: Patient name, DOB, and identifiers from task; screen header and patient info.
  Result: Confirm patient on screen matches request exactly by name and DOB before write.

- ANALYTIC MOVE: Compare note content entered with task note.
  Input: Note text shown on screen, task note text.
  Result: Confirm exact text from task is present in note field before saving.

- ARTIFACT CONTRACT: A saved encounter must contain:
  - Patient identity (name, MRN, DOB) matching the requested record fully.
  - Encounter type selected as requested (Triage).
  - Note field text identical to the instructed note.
  - Single save action per encounter to establish record.

- DECISION RULE: Trigger saving encounter only if patient identity matches task data exactly and note content matches requested note exactly.
  - Evidence support: Screen title, patient demographics, note field content.
  - Conflicts: If patient on screen differs from requested, do not write; report stopped.
  - Uncertainty: If identity uncertain or multiple candidates, do not attempt write; stop and explain.

- DECISION RULE: Trigger stopping the task if patient record cannot be found matching the task input.
  - Evidence: No patient screen with exact name and DOB.
  - Provide reason for stopping.

- ENCODING: Knowledge of patient matching and note verification is encoded in always-on checks:
  - Check patient header text fields for exact match.
  - Check note field text for exact string match.
  - Confirm encounter type selection matches task input.
  - Detect a single save button click per encounter.
  - Avoid duplicate saves by recognizing saved status on screen.

- HARD RULES:
  1. Do not write to a record unless patient identity matches exactly.
  2. Do not submit twice for the same encounter.
  3. If the requested patient cannot be found or confirmed, stop safely and explain why.

- WORKSPACE FACTS:
  - Patient "Jane Sample" in this workspace has MRN "P1" and DOB "1980-01-01".
  - The patient screen's header shows "Jane Sample — MRN P1 — DOB 1980-01-01".
  - The Triage encounter requires selecting the 'Triage' button and entering the 'Note' textarea.
  - Saving is done by clicking 'Save Encounter' exactly once.
  - Successful save updates the patient screen with text starting "Encounter saved — Triage:" plus portion of note.

- PROCEDURE:
  1. Locate and open the patient record matching name "Jane Sample" and DOB "1980-01-01".
  2. Start a new encounter, select 'Triage' encounter type.
  3. Enter the exact note text given by the task: "Triage: knee pain, ice and rest, follow up in two weeks."
  4. Click 'Save Encounter' once.
  5. Confirm save success by detecting updated screen status.
  6. Stop and report "saved" when complete.

- STOP condition handling:
  - If patient record not found or mismatched identity, stop with a clear reason rather than risk wrong patient write.
  - If duplicate encounter detected, do not resubmit; stop safely.

