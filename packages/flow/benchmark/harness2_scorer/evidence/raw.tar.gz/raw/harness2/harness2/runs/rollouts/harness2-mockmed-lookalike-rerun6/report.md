status: saved

Successfully recorded a Triage encounter for Jane Sample with the specified note.
