status: saved

Triage encounter for Jane Sample with note recorded successfully.
