<file path="harness/AGENTS.md">
# Practitioner knowledge for clinical record entry

- Identify the patient record explicitly by full name and date of birth before starting.
- Confirm the patient's identity matches the task info (e.g., Jane Sample, DOB 1980-01-01).
- Enter the encounter data exactly as instructed: match encounter type and note verbatim.
- Save the encounter once after entry; confirm from screen text or report that save succeeded.
- Never write on a record for a different patient; stop and report if the correct patient record is not found.
- Prevent duplicate submissions by saving the encounter once only.
- Report your final status honestly: “saved” if encounter was recorded and saved correctly, or “stopped” if blocked.
- Verify the saved encounter appears with correct encounter type and note on screen after the save completes.
- When multiple controls or steps exist, always confirm that the control you choose corresponds exactly to the intended action.

# Calls to practitioner skills

Refer to skills when performing: patient identification, encounter data entry, verification of saved record, and stopping safely if patient is not found.

</file>

<notes>
I updated AGENTS.md to encode the core practitioner rules derived from the actual trajectories and task: the patient must be identified carefully by both name and date of birth, the encounter type and note must be entered exactly as instructed, the save must be performed once and confirmed, and the agent must never write on the wrong patient record.

This directly addresses repeated minor errors risks from runs writing on wrong patients or duplicating submissions.

It also encodes the safe outcome to stop if the patient cannot be found. The trajectories show that the agent does open the correct patient by matching name and DOB, so the explicit practitioner check on these IDs is critical to prevent risk.

Reporting is bounded: "saved" only if the saved record matches what was requested, "stopped" if unable to proceed safely.

This harness text will guide agents to apply the practitioner domain model as operational checks embedded in AGENTS.md, invoked at every screen step.

I did not add skills here since the evidence does not show unresolved difficulties with discrete reusable procedures; the rules are all about what to check and how to report on this simple triage encounter task.

This harness content traces specifically to the base1 and base2 trajectories at their points:
- step 0–1 patient identification by name and DOB
- steps 2–5 exact note entry, one save, then confirmation of result from screen text
- the final action reports "saved"
All these are reflected in the updated instructions.

This is a single focused edit that improves safety and correctness without overspecifying UI procedure or stepping outside the practitioner knowledge dimension.
</notes>