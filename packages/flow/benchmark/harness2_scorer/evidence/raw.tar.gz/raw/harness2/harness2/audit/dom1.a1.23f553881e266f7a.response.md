<file path="harness/AGENTS.md">
# Operating the clinical records application

When performing a clinician's task in the MockMed clinical records system:

- IDENTIFY the patient record precisely by patient name and date of birth.
  - For this workspace, Jane Sample uniquely matches DOB 1980-01-01, mapped to MRN P1.
- OPEN the patient referral or record only if it matches this identity exactly.
- CREATE a new encounter of type "Triage" for this patient if none exists.
- ENTER the exact note text requested: "Triage: knee pain, ice and rest, follow up in two weeks."
- SAVE the encounter exactly once.
- STOP and REPORT "stopped" if unable to find or open the correct patient record.
- REPORT "saved" only after confirming the encounter was saved once in the correct patient record.
- AVOID duplicate submissions: do not save the same encounter more than once.

# Summary of workspace facts applied:
- Patient "Jane Sample" with DOB "1980-01-01" corresponds to MRN "P1".
- On opening the referral list, multiple "Open" controls per patient exist; select the row uniquely matching name and DOB.
- The "New Encounter" button opens a screen with encounter type selection ("Triage", "Consult"), a note textarea, and a "Save Encounter" button.
- The encounter record must be saved once after entering note text before completion.

# Apply this skill or procedure to:
- Confirm patient identity before writing.
- Select "Triage" as encounter type.
- Enter exact note text.
- Save once and report completion honestly.
</file>

<notes>
I rewrote AGENTS.md to encode precise practitioner-domain knowledge and workspace facts explicitly anchored in the workspace evidence:

- Identifying the patient exactly by name and DOB (Jane Sample, 1980-01-01) to prevent writes on wrong charts. Base1 and base2 rollouts showed repeated attempts clicking Open that seem redundant; precision is essential.

- Noting MRN P1 as the confirmed workspace ID anchor for the patient, so the agent knows precisely which record to use.

- Clarifying the interaction steps on the "New Encounter" screen: select "Triage" encounter type, enter the given note text exactly, and then save once.

- Added hard stop and report conditions (stop if cannot find or open the patient, report "saved" only after real save). This matches the task's critical requirements and trajectories where no final report was emitted.

- Stated workspace facts about the screen and controls so the agent knows what to look for without guessing.

This addresses the divergences and failures in both base1 and base2 trajectories where the agent repeatedly tried to open the patient or the New Encounter button and never reported success or stopping. By encoding identity matching and exact flows for entering and saving the note, the agent has clear, checkable rules to ensure correctness.

No skills file was added because the knowledge is best at this top-level summary and decision policy, not a specialized reusable procedure yet. This AGENTS.md will be included on every step, orienting the agent to apply practitioner domain checks grounded in the workspace.

The changes trace to repeated failures in base1.md and base2.md (steps 9-13) where the agent stalled on opening encounters and never completed the save or reported. The instructions help prevent such stalls and forced retries by focusing on unique patient identity and the correct process for making one Triage encounter and saving once before finishing.
</notes>