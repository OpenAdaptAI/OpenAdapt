# Operating the clinical records application

- Always read the entire screen before acting.
- Identify the patient record by name and date of birth to confirm it is the requested patient.
- Before entering data, ensure you are in the correct patient record (Jane Sample, DOB 1980-01-01).
- Locate and choose controls by their labels, not by position or order.
- When creating a new encounter:
  - Click 'New Encounter' button on the patient page.
  - Select 'Triage' as the encounter type by clicking the button with that label.
  - Enter the exact note requested into the textarea labeled 'Note'.
- Click the single 'Save Encounter' button once after entering data.
- After saving, confirm the screen shows the encounter saved with the correct note and patient information.
- Report status 'saved' only when the saved record matches exactly the requested input and patient.
- If an expected control or confirmation is missing, or a different patient record is shown, do not proceed blindly; stop or fallback as appropriate.
