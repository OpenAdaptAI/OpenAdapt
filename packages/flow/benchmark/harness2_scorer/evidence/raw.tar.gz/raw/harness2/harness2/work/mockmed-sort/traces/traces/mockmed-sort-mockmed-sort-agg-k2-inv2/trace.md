# Trace mockmed-sort-mockmed-sort-agg-k2-inv2

- task: mockmed/sort
- candidate: inv2
- source: agent_rollout
- outcome: verified
- reward: 1.0

## Steps

### Step 0
Screen:
```
SCREEN (#tasks):
MockMed Clinical demo — all data is fake
Referral Tasks
Patient	Reason	Priority	Action
Alex Testcase	Cardiology follow-up	Medium	Open
Jane Sample	Knee pain referral	High	Open
Sam Specimen	Dermatology consult	Low	Open

CONTROLS:
[1] button 'Open' (row: Alex Testcase Cardiology follow-up Medium)
[2] button 'Open' (row: Jane Sample Knee pain referral High)
[3] button 'Open' (row: Sam Specimen Dermatology consult Low)
```
Action: click [2] 'Open'
Reason given: Click on the 'Open' button for Jane Sample to access her record.

### Step 1
Screen:
```
SCREEN (#patient/p1):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
New Encounter
Encounters

No encounters yet.

CONTROLS:
[1] button 'New Encounter'
```
Action: click [1] 'New Encounter'
Reason given: Open the new encounter form for Jane Sample by clicking 'New Encounter'.

### Step 2
Screen:
```
SCREEN (#encounter):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
New Encounter
Encounter Type
Triage
Consult
Note
Save Encounter

CONTROLS:
[1] button 'Triage'
[2] button 'Consult'
[3] textarea 'Note'
[4] button 'Save Encounter'
```
Action: click [1] 'Triage'
Reason given: Verify the encounter type is set to Triage and enter the note, then save the encounter.

### Step 3
Screen:
```
SCREEN (#encounter):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
New Encounter
Encounter Type
Triage
Consult
Note
Save Encounter

CONTROLS:
[1] button 'Triage' (selected)
[2] button 'Consult'
[3] textarea 'Note'
[4] button 'Save Encounter'
```
Action: type into [3]: 'Triage: knee pain, ice and rest, follow up in two weeks.'
Reason given: Verify that Jane Sample's record is open and 'Triage' encounter type is selected. Enter the note in the 'Note' textarea. Then click 'Save Encounter' to save the record.

### Step 4 (write)
Screen:
```
SCREEN (#encounter):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
New Encounter
Encounter Type
Triage
Consult
Note
Save Encounter

CONTROLS:
[1] button 'Triage' (selected)
[2] button 'Consult'
[3] textarea 'Triage: knee pain, ice and rest, follow up in two weeks.' value='Triage: knee pain, ice and rest, follow up in two weeks.'
[4] button 'Save Encounter'
```
Action: click [4] 'Save Encounter'
Reason given: Verify that patient is Jane Sample with DOB 1980-01-01, then save the encounter.
Identity at this step: verified (agent_screen); expected Jane Sample — DOB 1980-01-01; on screen Jane Sample — DOB 1980-01-01

### Step 5
Screen:
```
SCREEN (#patient/p1):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
Encounter saved — Triage: knee pain, ice and rest, follow
New Encounter
Encounters
Triage — Triage: knee pain, ice and rest, follow up in two weeks.

CONTROLS:
[1] button 'New Encounter'
```
Action: done status=saved: Triage encounter for Jane Sample recorded successfully.
Reason given: The encounter has been saved successfully, and the screen confirms the message 'Encounter saved — Triage: knee pain, ice and rest, follow' and the 'Triage' encounter type. I will stop as the task is complete.

## Read-back from the system of record
- added: patient p1, type Triage, note 'Triage: knee pain, ice and rest, follow up in two weeks.'
- the requested patient gained 1 record(s); other patients gained 0
- outcome: verified (every required effect is present exactly as declared)
- receipt: reward_receipt_dc0390811d694c17a9f7e038ef6746cb (oracle tier 2)

## The agent's own report
Triage encounter for Jane Sample recorded successfully.
