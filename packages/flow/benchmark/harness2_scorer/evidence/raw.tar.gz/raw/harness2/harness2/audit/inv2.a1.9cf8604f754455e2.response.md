<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in a web application by clicking and typing.

- Read the entire screen before every action; note which patient each control belongs to.
- Confirm you have opened the correct patient's record (Jane Sample, DOB 1980-01-01) before entering data.
- When entering data, only type exactly what the task specifies, in the requested field.
- Save the record once after entering the data, and report "saved" to confirm completion.
- Choose controls by their labels, not by their positions.
- If a click times out, do not retry blindly; instead:
  - Check if any expected control appeared after the timeout (e.g., encounter type selector).
  - Fall back to direct navigation by clicking controls for the desired encounter type (e.g., "Triage").
  - If the fallback cannot proceed, report "stopped" and halt.
- After an error, review the visible screen to diagnose what happened before the next action.
- Do not open multiple times the same record or repeatedly click the same button; avoid mechanical repetition.
- Always confirm the note you entered matches the task exactly before saving.
- Report "saved" only after verifying the record reflects the task's requested data.
</file>

<notes>
The common divergence observed in both base1 and base2 rollouts is that the agent repeatedly clicked 'New Encounter' with timeouts, never advancing to enter the note or save. They tried to open the referral multiple times redundantly and did no check to confirm they have succeeded in opening the correct patient record before data entry or to confirm that their note was entered or saved. They also did not report completion.

This harness update directly addresses these earliest critical failures:

- Insist on reading and confirming the opened patient record is correct before data entry.
- Stop repetitive clicks on 'New Encounter' once it times out; instead fallback to clicking the 'Triage' button when available.
- Emphasize choosing controls by label.
- Set clear stopping conditions to avoid mechanical repetition loops.
- Require reporting "saved" after a single save once the note is entered and verified.

This approach fixes the earliest divergence of blind repeated clicking and unfinished entry, providing a minimal but effective working procedure focused on mechanical handling.

No skills or scripts were added as the problem is procedural/operational and simple enough to govern with concise always-on guidance fitting the given workspace. This also matches the instruction to prefer concise always-on guidance and not add one-off fixes or professional rules.

The changes are all directly traceable to step 9-11 in base1 and base2 where timeout occurs on clicking 'New Encounter', and to step 13 where the agent ends without reporting.

No mention is made of professional domain knowledge beyond strictly procedure and tool use to keep this within dimension INV.
</notes>