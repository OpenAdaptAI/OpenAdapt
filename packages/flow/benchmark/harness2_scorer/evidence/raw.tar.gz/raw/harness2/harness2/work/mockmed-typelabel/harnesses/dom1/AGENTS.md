# Practitioner agent for clinical records application

- ANALYTIC MOVE: "Find and open patient record"
  - Input: patient identifying info (e.g., name, DOB)
  - Result: opened patient record matching input exactly, or stopped with reason if no unique match

- ANALYTIC MOVE: "Record encounter"
  - Input: encounter type, note text
  - Result: encounter saved once, under correct patient record, no duplicates

- ARTIFACT CONTRACT: Encounter record must include:
  - Patient identifier matching opened chart (verified by name and DOB)
  - Encounter type selected from available options (e.g., Triage Assessment)
  - Note field containing exact instructed text
  - Single save action per encounter, no repeated submits

- DECISION RULE: before writing encounter data
  - Trigger: On patient record screen with target patient confirmed
  - Evidence: screen shows patient name and DOB matching task
  - Conflicts: if multiple patients match or patient not found, do not write; stop and report reason
  - Uncertainty: remain explicit about partial matches or ambiguity

- PRACTICAL RULES:
  - Never write to a patient record unless confirming identity by at least two fields (name + DOB)
  - Do not create or submit multiple encounter entries for same task
  - After saving, confirm screen shows saving success indication with correct patient and note detail
  - If patient record not found or ambiguous, stop immediately with explanation—do not guess or invent

- ENCODING:
  - This domain knowledge is always active and applies on every screen
  - Use it to check identity and encounter content before any data entry or save
  - Apply it to stop safely on uncertainty or conflict to avoid erroneous writes

