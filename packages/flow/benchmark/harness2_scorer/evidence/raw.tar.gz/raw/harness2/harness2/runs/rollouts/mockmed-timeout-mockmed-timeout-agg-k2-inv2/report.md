status: stopped

Encounter save timed out; it is uncertain whether the data was saved.
