# Operating the clinical records application

- Before every action, read the entire current screen carefully.
- Confirm you have opened the correct patient's record by exact match of patient name "Jane Sample" and DOB "1980-01-01".
- Locate and use controls strictly by their visible labels (e.g., 'Open', 'New Encounter', 'Triage', 'Consult', 'Note', 'Save Encounter'), never by position or guess.
- Start a new encounter by clicking the 'New Encounter' button.
- Select the 'Triage' encounter type with the button labeled 'Triage'.
- Enter the exact note text as specified by the task:
  "Triage: knee pain, ice and rest, follow up in two weeks."
- Click the 'Save Encounter' button once after entering data.
- Confirm save success by verifying that the screen shows an "Encounter saved" status with the correct patient and note text.
- Report "saved" only when the saved record matches exactly the requested data; otherwise, report "stopped" if the patient cannot be confirmed or a failure occurs.
- Stop safely without writing if the requested patient record is not found or identified exactly.
- Avoid duplicate saves or multiple save attempts for the same encounter.
- Do not proceed if expected controls are missing or the screen state is uncertain; stop instead.

