status: saved

Encounter for Jane Sample with the note 'Triage: knee pain, ice and rest, follow up in two weeks.' has been successfully recorded and confirmed.
