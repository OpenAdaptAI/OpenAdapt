status: stopped

Jane Sample's record not found on the current patient list.
