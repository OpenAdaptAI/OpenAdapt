<file path="harness/AGENTS.md">
# Operating the clinical records application

- Before starting, confirm the correct patient is found and opened by checking that the displayed patient name and date of birth exactly match the requested patient (here, Jane Sample, DOB 1980-01-01).
- If the correct patient record cannot be found or opened exactly, stop and report why.
- To record a Triage encounter accurately:

  1. Click the 'New Encounter' button only after confirming the correct patient.
  2. Select the 'Triage' encounter type explicitly.
  3. Enter exactly the note text supplied by the task into the 'Note' field.
  4. Click 'Save Encounter' exactly once to save the record.

- After saving, verify the encounter appears on the patient screen with the correct note text as confirmation.
- Do not click 'Save Encounter' multiple times; avoid repeated or blind retries to prevent timeouts and failures.
- If the 'Save Encounter' button is not visible or enabled, try scrolling it into view once before clicking; if still failing, stop and report.
- Only report "saved" after confirming that the encounter was saved under the right patient with the exact note.
- Report "stopped" if the correct patient record cannot be found or opened, or if saving or verification fails.
- Never invent or guess patient identifiers or encounter codes; rely strictly on what is displayed and verifiable on screen.
- Always read the entire screen before every action to confirm context and prevent errors.

</file>

<notes>
revised -> dom1 and dom2 edits for patient identity verification, exact encounter steps, and safe single save with verification -> both candidates & base2 rollout confirm importance of exact patient name and DOB check and not saving multiple times; avoids base1 failing pattern (2/2 base rollouts show save click timeout failures except base2 succeeds); each dom candidate encodes explicit domain procedure on patient and encounter steps.

revised -> inv1 and inv2 edits for mechanical interaction safety: one save click only, avoid blind retries on save, fallback scrolling once, stop and report on timeout, confirm saved record matches request before reporting "saved" -> supported by base1 repeated timeout failures and base2 single click success and correct report; inv edits precisely address timing and control issues in base1 rollout step 6-13 and prevent infinite save clicks.

dropped -> keep_base as it fails repeatedly with timeout and no report (empty deliverable in base1); unstable, costs correctness, regressions risk.

merged -> combine all domain and invitational epistemic improvements into a single AGENTS.md to encompass patient checking and safe save procedures, avoiding overlaps and contradictions into a consistent single harness - no skills needed as per evidence; instructions are concise, direct, and grounded exclusively on observable UI and task data.
</notes>