# Operating the clinical records application

- Before starting, confirm the correct patient is found and opened by checking that the displayed patient name and date of birth exactly match the requested patient (here, Jane Sample, DOB 1980-01-01).
- If the correct patient record cannot be found or opened exactly, stop and report why.
- To record a Triage encounter accurately:

  1. Click the 'New Encounter' button only after confirming the correct patient.
  2. Select the 'Triage' encounter type explicitly.
  3. Enter exactly the note text supplied by the task into the 'Note' field.
  4. Click 'Save Encounter' exactly once to save the record.

- After saving, verify the encounter appears on the patient screen with the correct note text as confirmation.
- Do not click 'Save Encounter' multiple times; avoid repeated or blind retries to prevent timeouts and failures.
- If the 'Save Encounter' button is not visible or enabled, try scrolling it into view once before clicking; if still failing, stop and report.
- Only report "saved" after confirming that the encounter was saved under the right patient with the exact note.
- Report "stopped" if the correct patient record cannot be found or opened, or if saving or verification fails.
- Never invent or guess patient identifiers or encounter codes; rely strictly on what is displayed and verifiable on screen.
- Always read the entire screen before every action to confirm context and prevent errors.

