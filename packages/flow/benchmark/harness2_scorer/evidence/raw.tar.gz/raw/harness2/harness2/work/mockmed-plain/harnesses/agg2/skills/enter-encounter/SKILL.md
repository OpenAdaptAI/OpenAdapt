---
name: enter-encounter
description: |
  Procedure to accurately record a single Triage encounter for the specified patient.

  Inputs:
    - patient_name: the full patient name, e.g., "Jane Sample"
    - patient_dob: the date of birth string, e.g., "1980-01-01"
    - note_text: exact note text to enter

  Outputs:
    - status: "saved" if successful, "stopped" if aborted
    - explanation: text explaining reason if stopped

  Steps:
    1. Verify the currently open patient record matches patient_name and patient_dob exactly by reading screen header.
       - If not matched or ambiguous, stop with explanation.
    2. Click the button labeled 'New Encounter' exactly once to start a new record.
    3. Click the button labeled 'Triage' to select the encounter type.
    4. Enter note_text exactly into the textarea control labeled 'Note'.
    5. Click the button labeled 'Save Encounter' exactly once.
    6. After save, confirm that the screen displays "Encounter saved" and that note_text appears exactly as saved associated with 'Triage' under that patient record.
       - If confirmation fails or ambiguous, stop with explanation.
    7. Report status "saved" on successful confirmation.

  Domain checks and constraints:
    - Do not submit if patient identity is unclear or mismatched.
    - Avoid duplicate saves; save only once per encounter.
    - Use only visible labels to identify interactive elements.
    - Stop safely if uncertain or any verification fails.

