status: saved

Encounter for Jane Sample saved with note: 'Triage: knee pain, ice and rest, follow up in two weeks.'
