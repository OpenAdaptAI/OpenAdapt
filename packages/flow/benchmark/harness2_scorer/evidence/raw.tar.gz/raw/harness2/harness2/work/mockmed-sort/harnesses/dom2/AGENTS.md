# Operating the clinical records application

## Analytic Moves

- Identify patient record by comparing name and DOB to avoid wrong chart writes.
- Reconcile entered encounter data with the task note: confirm all requested text is present exactly.
- Calculate whether any duplicate encounter already exists for this patient and note to avoid repeats.
- Trace the workflow steps: open patient, create encounter, select type, enter note, save once.
- Explain and report clearly: record saved or stopped with reason if patient not found.

## Artifact Contract

- Patient record must be selected by exact name and date of birth match.
- Encounter artifact requires:
  - Encounter type (Triage, Consult, etc.)
  - Note text matching the task request exactly.
  - Save operation performed once.
- Saved encounter must appear in patient record after save with all requested data.

## Decision Rules

- Trigger: Task requires recording a Triage encounter for a named patient with a specific note.
- Evidence: Screen patient header matches name & DOB; encounter note matches requested content; "Save" performed once.
- Conflicts: If patient not found, stop and report inability to proceed.
- If duplicate encounter with identical note exists, recognize it as duplicate; do not create new.
- Maintain explicit uncertainty if record status ambiguous; confirm save screen or message.

## Encoding: Skill Usage

- Use a skill for "patient record selection" to match name and DOB exactly.
- Use a skill "encounter creation" that:
  - Selects encounter type per task.
  - Enters exact note text from task.
  - Performs exactly one save.
- Report final status as "saved" if encounter recorded successfully or "stopped" with reason if patient missing.
- Always verify the saved record content matches requested note (not just screen text).

## Workspace Fact

- The patient "Jane Sample" uniquely identified by Name "Jane Sample" and DOB "1980-01-01" has MRN "P1".
- Encounter screens show controls "Triage" and "Consult" buttons and a single "Note" textarea named 'Note'.
- Save operation uses button labeled "Save Encounter".
- After saving, the patient screen indicates "Encounter saved" with the entered note visible.

# Practical Instructions

- Before writing, confirm you have the right patient by matching both displayed name and DOB exactly.
- Enter the note exactly as specified: "Triage: knee pain, ice and rest, follow up in two weeks."
- Click "Save Encounter" once, then confirm the screen shows the note saved under encounters.
- Do not attempt to create duplicate encounters with identical notes for the same patient.
- If the correct patient record cannot be found or does not match, stop and report.

