status: saved

The Triage encounter for Jane Sample has been recorded and confirmed successfully.
