status: stopped

Jane Sample not found in current patient list.
