<!-- candidate B: 312 chars, 18 lines. COMPLETE -- nothing trimmed. Navigate with grep/offsets; evaluating a candidate means opening the part that determines whether it works.
-->
## The agent's report

status: saved

Triage encounter for Jane Sample recorded successfully.

## The last screen it saw

SCREEN (#patient/p1):
MockMed Clinical demo — all data is fake
Jane Sample — MRN P1 — DOB 1980-01-01
Encounter saved —
New Encounter
Encounters
Triage —

CONTROLS:
[1] button 'New Encounter'