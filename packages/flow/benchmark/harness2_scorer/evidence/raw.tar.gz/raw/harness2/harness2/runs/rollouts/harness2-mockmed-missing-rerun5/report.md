status: stopped

Jane Sample is not displayed on the current screen; cannot proceed with recording the encounter.
