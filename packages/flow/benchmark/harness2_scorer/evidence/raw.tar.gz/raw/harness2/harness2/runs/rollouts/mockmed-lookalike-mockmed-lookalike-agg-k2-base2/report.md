status: saved

Triage encounter for Jane Sample has been recorded and saved successfully.
