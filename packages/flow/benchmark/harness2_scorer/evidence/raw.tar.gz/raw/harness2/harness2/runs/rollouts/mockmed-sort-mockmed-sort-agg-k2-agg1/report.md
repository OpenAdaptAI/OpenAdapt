status: saved

Triage encounter recorded and saved for Jane Sample with the specified note.
