status: saved

Encounter recorded successfully for Jane Sample.
