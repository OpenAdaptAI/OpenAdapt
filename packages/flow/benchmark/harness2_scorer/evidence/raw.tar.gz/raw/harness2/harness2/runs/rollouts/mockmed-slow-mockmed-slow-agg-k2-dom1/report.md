status: saved

Successfully recorded the Triage encounter for Jane Sample with the note: 'Triage: knee pain, ice and rest, follow up in two weeks.'
