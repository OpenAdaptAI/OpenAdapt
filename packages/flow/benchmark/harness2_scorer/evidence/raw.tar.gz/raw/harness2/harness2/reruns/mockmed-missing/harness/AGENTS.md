# Operating the clinical records application for a Triage encounter

- Confirm before any action that you have opened the correct patient record matching the requested patient exactly by name and date of birth.
- If the correct patient record is not found or opened, stop and report with a clear reason.
- To record a Triage encounter on the correct patient:
  1. Click the 'New Encounter' button.
  2. Select the 'Triage' encounter type.
  3. Enter exactly the note text specified by the task into the 'Note' field.
  4. Click the 'Save Encounter' button exactly once.
- Do not retry clicking the save button repeatedly; if the save cannot be completed due to visibility, enabled state, or timeout, try scrolling once, then stop and report.
- After saving, verify the encounter appears in the patient's record with the exact note text matching the task.
- Only report "saved" if the correct patient record shows the confirmed Triage encounter saved with the requested note.
- If unable to verify correct patient or successful save, report "stopped" with a clear explanation.
- Identify controls strictly by their visible labels, never by position alone.
- Never invent or guess patient IDs or encounter codes; rely only on what is displayed and verified on screen.

