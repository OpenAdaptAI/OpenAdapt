status: saved

Triage encounter for Jane Sample successfully recorded with note: 'Triage: knee pain, ice and rest, follow up in two weeks.'
