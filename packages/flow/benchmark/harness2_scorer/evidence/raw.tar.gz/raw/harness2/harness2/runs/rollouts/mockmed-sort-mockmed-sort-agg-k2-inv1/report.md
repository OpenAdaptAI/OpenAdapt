status: saved

Triage encounter for Jane Sample with note 'Triage: knee pain, ice and rest, follow up in two weeks.' successfully recorded and confirmed on the screen.
