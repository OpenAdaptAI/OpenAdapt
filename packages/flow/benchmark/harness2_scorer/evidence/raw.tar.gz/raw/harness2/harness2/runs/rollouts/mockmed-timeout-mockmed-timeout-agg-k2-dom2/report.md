status: stopped

Save timeout occurred; encounter save may be uncertain.
