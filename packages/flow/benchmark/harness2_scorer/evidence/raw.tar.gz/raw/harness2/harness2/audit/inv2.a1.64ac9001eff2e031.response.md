<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in a web application by clicking and typing.

- Read the entire screen before every action; note the patient name and date of birth shown on the screen.
- Confirm the record open matches the requested patient ('Jane Sample', DOB 1980-01-01) before entering data.
- Choose controls by their label, never by position.
- Enter exactly the note requested: "Triage: knee pain, ice and rest, follow up in two weeks."
- Save the encounter once by clicking the 'Save Encounter' button.
- After clicking save:
  - Read the screen to confirm the save succeeded.
  - If a message says "Save timed out — the encounter may or may not have been saved," do not repeat saving blindly.
  - Instead, stop and report the ambiguous save status honestly.
- Report "saved" if the save succeeded unambiguously.
- Report "stopped" if unable to confirm the save or after detecting a timed out save message.
- Do not repeatedly click 'Save Encounter' after a timeout message; this causes unnecessary repetition and fails the task.
</file>

<notes>
The base run evidence, especially rollouts base1 and base2, both showed repeated save attempts after "Save timed out" messages with no confirmation of success or failure. The agent never terminated or reported its outcome.

This is a clear mechanical repetition failure: the agent blindly repeats saving multiple times on ambiguous timeout. The cheapest fix is a rule to check the save status after one click, and to halt (report "stopped") upon timeout rather than repeat saving blindly. This matches instructions on TOOL ERROR fallback: distinguish bad input from timeout, stop with a bounded fallback (one save attempt), and never blind repeat.

Also added necessary workspace-specific guidance from the screen text (patient name and DOB confirmation) because evidence shows that matching patient before entering is vital. The agent must confirm the exact record before entry. This is a workspace fact derived from the screens and task.

By the reports, the save ambiguity is common; the agent must report honestly instead of looping forever. This fix is minimal and directly traces to the failing moments from step 5 onward in both base1 and base2 rollouts.

No skills or scripts were added because the problem is mechanical repetition and error condition handling, best solved with a concise AGENTS.md rule.

This removes the endless save clicks and prompts the agent to stop and report honestly once it encounters the timeout save message, improving overall behavior significantly.
</notes>