<file path="harness/AGENTS.md">
# Operating the clinical records application

- Before every action, read the entire current screen carefully.
- Confirm you have opened the correct patient's record by exact match of patient name "Jane Sample" and DOB "1980-01-01".
- Locate and use controls strictly by their visible labels (e.g., 'Open', 'New Encounter', 'Triage', 'Consult', 'Note', 'Save Encounter'), never by position or guess.
- Start a new encounter by clicking the 'New Encounter' button.
- Select the 'Triage' encounter type with the button labeled 'Triage'.
- Enter the exact note text as specified by the task:
  "Triage: knee pain, ice and rest, follow up in two weeks."
- Click the 'Save Encounter' button once after entering data.
- Confirm save success by verifying that the screen shows an "Encounter saved" status with the correct patient and note text.
- Report "saved" only when the saved record matches exactly the requested data; otherwise, report "stopped" if the patient cannot be confirmed or a failure occurs.
- Stop safely without writing if the requested patient record is not found or identified exactly.
- Avoid duplicate saves or multiple save attempts for the same encounter.
- Do not proceed if expected controls are missing or the screen state is uncertain; stop instead.

</file>

<notes>
revised -> pool/dom1/harness/AGENTS.md -> anchors practitioner domain knowledge, patient and note matching, single save, domain facts and decision rules explicitly to address base runs repeating risks of wrong patient or saves (2/2 base runs)
revised -> pool/dom2/harness/AGENTS.md -> incorporates thorough domain encoding of patient identity, encounter artifact contract, stopping rules and avoidance of duplicates, closely matching workspace evidence (2/2 base runs)
revised -> pool/inv1/harness/AGENTS.md -> adds precise procedural invariant instructions on reading screen, confirming patient identity and exact control labels with single save, preventing risky assumptions (2/2 base runs)
revised -> pool/inv2/harness/AGENTS.md -> clarifies reading screen, control label use, single save, stop on error, confirms patient before write, with explicit stop/report rules (2/2 base runs)
dropped -> pool/dom2/harness/skills/README.md -> no skills invoked or useful from evidence
dropped -> pool/dom1/harness/skills/README.md -> no reusable skills evidenced needed
dropped -> pool/inv1/harness/skills/README.md -> no skills added as unnecessary
dropped -> pool/inv2/harness/skills/README.md -> no skills added
kept_base -> harness/AGENTS.md pre-edit version was minimal but insufficient; evidence strongly encourages adding explicit patient identity matching, note matching, save-once, stop-if-not-matching rules rather than kept base
Merge rationale:
- All runs (base + candidates) show same successful sequence: patient opened by exact name/DOB, new encounter started, 'Triage' selected, exact note entered, saved once, final screen confirms save.
- No runs produced failure or no output.
- All candidate edits address the same repeated failure risks seen in base runs: wrong patient writes, no patient identity confirmation, multiple saves.
- All candidate edits agree patient identity and note exact matching are essential; each adds more detail or overlap to these rules.
- No skill-based approach demonstrated advantage or additional clarity; skills unnecessary for this simple task family.
- Small divergences in typing style or steps are irrelevant as all converge on the critical invariant: patient confirmed, note entered precisely, saved once.
- Therefore, merge the edits by composing a single AGENTS.md embodying all key invariants, practical procedural steps, and domain checks from DOM and INV edits, fully consistent with the successful rollouts and domain evidence.
- Do not add unsubstantiated fallback or retry mechanisms; rollout evidence shows a straightforward path suffices.
- Avoid redundancy by stating each principle once, clearly and succinctly.
- No empty files or skill files emitted, as none are needed for this scope.

</notes>