status: saved

Triage encounter for Jane Sample successfully recorded and saved.
