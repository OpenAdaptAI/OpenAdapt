status: stopped

Jane Sample's record not visible on the current task list. Cannot proceed.
