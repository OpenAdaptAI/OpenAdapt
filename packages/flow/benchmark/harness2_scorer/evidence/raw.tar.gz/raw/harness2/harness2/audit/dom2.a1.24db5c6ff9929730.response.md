<file path="harness/AGENTS.md">
# Operating the clinical record application

This harness guides the agent to find the correct patient, enter the requested encounter data exactly as asked, and save it once only.

- ANALYTIC MOVE: Select and open the patient record by matching the full name and date of birth given in the task, never using partial or guessed matches.

- ARTIFACT CONTRACT: The encounter record must include:
    - Encounter type: selected as specified (e.g., "Triage")
    - Note text: matching exactly the given note text
    - Patient identity: confirmed by both name and DOB to avoid writes to the wrong chart

- DECISION RULE:
    - Trigger: when the task requests entering an encounter note for a named patient.
    - Evidence: confirm exact patient match in screen identifiers (name and DOB).
    - Stop and report "stopped" if the right patient cannot be found unambiguously.
    - Save the encounter once after entering all values as requested.
    - Explicitly avoid clicking Save multiple times.
    - If a save appears to have timed out or failed, report the uncertainty but do not retry endlessly.
    - Avoid duplicate submissions which cause record duplication.

- ENCODING: Always parse and confirm patient identity from screen headers showing name and date of birth. Use a skill for "ConfirmPatientWithDOB" (to be authored) invoked on opening the record. Confirm the exact note contents before saving.

- Reporting:
    - Upon a successful save, report "saved".
    - If stopped (patient not found or ambiguity), report "stopped".
    - Never silently retry saves multiple times when the screen shows uncertainty; instead report the status honestly.

- WARNINGS:
    - A write to the wrong patient is worse than no write.
    - Multiple save clicks may cause duplicated encounters; only save once.
    - A save reporting "timed out" makes the save outcome uncertain—do not retry blindly but report carefully.

This domain knowledge applies specifically to the MockMed Clinical demo application screens and the task of entering triage encounter notes.

</file>

<notes>
I rewrote the AGENTS.md harness text to encode explicit, checkable practitioner knowledge derived from the task and rollout evidence:

- The major failure common across rollouts was that they saved the encounter multiple times after seeing a "Save timed out" message.
- Practitioner domain knowledge states only one save should be done per new encounter to avoid duplicates.
- The harness now mandates identifying the correct patient by full name + DOB, crucial to avoid wrong chart writes.
- The agent must stop and report if patient identity is not confirmed exactly.
- The ambiguity of "Save timed out" means the agent must report this uncertainty but not try to save repeatedly, as that caused repeated clicks and ultimately failure (no final report).
- The knowledge is encoded as analytic move, artifact contract, decision rule, encoding, and reporting directives to be immediately actionable.
- I mention a skill "ConfirmPatientWithDOB" to explicitly handle patient identity confirmation, which is crucial.
- This change traces directly to the divergence moment at step 5+ in base1.md and base2.md, where the agent repetitively clicked Save after timeouts instead of stopping with an honest report.
- This harness is scoped specifically to the task family in this workspace, guarding grounded facts and rules to avoid repeats of these errors.

This rewrite is succinct and practitioner-centered, no longer allowing repeated save clicks or guessing at save success, and requiring exact patient confirmation. It guides the agent on when to stop with explanation vs proceed.

No other files are changed, as the domain knowledge resides here and the skill (ConfirmPatientWithDOB) can be added later if needed.

</notes>