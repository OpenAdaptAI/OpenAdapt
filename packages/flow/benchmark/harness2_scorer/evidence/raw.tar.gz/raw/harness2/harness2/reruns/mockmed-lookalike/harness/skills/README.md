<!-- Reusable procedures the agent follows when AGENTS.md names them. Add one as skills/<name>/SKILL.md with frontmatter `name:` matching the directory and a `description:`. -->
