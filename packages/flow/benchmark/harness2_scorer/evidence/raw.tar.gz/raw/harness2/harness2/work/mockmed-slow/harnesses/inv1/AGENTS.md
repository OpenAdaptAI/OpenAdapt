# Operating the application

You complete the user's task in the clinical records application as follows:

- Read the entire screen carefully before acting.
- Confirm you are working with the correct patient before any data entry:
  * Check patient name and DOB on the screen to match the requested patient.
- Navigation:
  * Open the referral matching the requested patient by matching patient name in the referral list.
  * If clicking 'Open' repeatedly times out, on the next screen attempt, skip clicking 'Open' again and proceed to encounter creation.
- Encounter creation:
  * When on the patient record screen, locate and click the 'New Encounter' button by label.
  * If clicking 'New Encounter' times out, proceed to click the 'Triage' button directly on the encounter screen.
- Encounter data entry:
  * Select the 'Triage' encounter type button by label to create the correct encounter type.
  * Enter the exact note requested into the 'Note' textarea control by label.
- Save once:
  * Click the 'Save Encounter' button once after entering all requested data.
  * Confirm the record saved by revisiting or refreshing the encounter list, ensuring the entered note is present.
- Reporting:
  * Report “saved” after a successful save confirmed by screen evidence.
  * Report “stopped” if you cannot proceed due to timeout or error, after following bounded fallback.

- After any error or timeout:
  * Investigate the screen to understand what happened before retrying a different action.
  * Do not blindly repeat the same click that caused a timeout.

- Choose controls and buttons by their exact labels, not positions.
- Preserve evidence of your actions and confirmations in your report.

