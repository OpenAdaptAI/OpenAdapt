# Operating the application for clinical record entries

Before writing, find and open the correct patient record by matching their full name and date of birth exactly.

- ANALYTIC MOVE: Confirm Patient Identity
  - Input: Patient name and DOB per task
  - Result: Open patient record screen matching these exactly
  - If no exact match, stop and report "stopped" with explanation why not found.

- ANALYTIC MOVE: Enter Encounter Data
  - Input: Encounter type (Triage), text note from task
  - Result: Encounter UI fields filled exactly as asked, no extra text

- ANALYTIC MOVE: Save Encounter Once
  - Input: Encounter data fully entered
  - Result: Save button clicked exactly once, no retries or duplicates

- ARTIFACT CONTRACT: Encounter Record
  - Required parts:
    - Patient identifier from open record screen (name, DOB, MRN)
    - Encounter type (Triage)
    - Encounter note text exactly matching task instruction
  - Dependencies: Patient record must be opened first
  - Domain checks:
    - Patient identity fields match task inputs exactly
    - Only one encounter is created per run to avoid duplicates
    - Saved record reflects the entered note (visible confirmation)

- DECISION RULE: Stop if patient record not found exactly
  - Trigger: Failure to find exact patient name and DOB
  - Evidence: Screen patient list or open record shows no exact match
  - Conflicts: None; priority is zero writes unless correct patient found
  - Explicit uncertainty: Report inability to locate patient

- DECISION RULE: Avoid duplicate encounter writes
  - Trigger: Encounter already saved for this input
  - Evidence: Encounter list shows matching note present
  - Resolution: Do not submit a second time; report saved success

- ENCODING: This domain knowledge is always applied in every step controlling the UI
  - Name this skill "ClinicalEncounterEntry" and register it in AGENTS.md
  - The skill includes the operations named above for checking before write, saving once, and confirming saved

- Reporting:
  - On success: report "saved"
  - On stop before writing: report "stopped" with reason

- Do not invent patient identifiers; rely on displayed patient name and DOB exactly.

- Use the on-screen confirmation message as evidence of a successful save.

- Never write if the right patient is not open.

