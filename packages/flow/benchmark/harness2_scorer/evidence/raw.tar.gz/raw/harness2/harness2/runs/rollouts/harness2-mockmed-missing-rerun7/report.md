status: stopped

Jane Sample's patient record is not accessible from the current screen; cannot proceed to record Triage encounter.
