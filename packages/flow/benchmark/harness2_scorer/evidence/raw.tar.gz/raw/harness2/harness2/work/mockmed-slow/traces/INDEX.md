# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-slow-mockmed-slow-agg-k2-dom1](traces/mockmed-slow-mockmed-slow-agg-k2-dom1/trace.md) | mockmed/slow | dom1 | verified | 1.0 |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-agg2](traces/mockmed-slow-mockmed-slow-agg-k2-agg2/trace.md) | mockmed/slow | agg2 | halted_before_effect | 0.0 |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-base1](traces/mockmed-slow-mockmed-slow-agg-k2-base1/trace.md) | mockmed/slow | base1 | halted_before_effect | 0.0 |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-base2](traces/mockmed-slow-mockmed-slow-agg-k2-base2/trace.md) | mockmed/slow | base2 | halted_before_effect | 0.0 |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-inv2](traces/mockmed-slow-mockmed-slow-agg-k2-inv2/trace.md) | mockmed/slow | inv2 | halted_before_effect | 0.0 |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-dom2](traces/mockmed-slow-mockmed-slow-agg-k2-dom2/trace.md) | mockmed/slow | dom2 | reconciliation_required | - |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-inv1](traces/mockmed-slow-mockmed-slow-agg-k2-inv1/trace.md) | mockmed/slow | inv1 | reconciliation_required | - |  |  |
| [mockmed-slow-mockmed-slow-agg-k2-agg1](traces/mockmed-slow-mockmed-slow-agg-k2-agg1/trace.md) | mockmed/slow | agg1 | reconciliation_required | -1.0 |  | yes |
