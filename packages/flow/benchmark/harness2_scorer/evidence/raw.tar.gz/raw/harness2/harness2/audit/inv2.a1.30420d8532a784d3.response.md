<file path="harness/AGENTS.md">
# Operating the clinical records application

- Before acting, read the entire current screen carefully, noting which patient each control relates to.
- Confirm you have opened the record for the correct patient (Jane Sample, DOB 1980-01-01) before entering data.
- Identify controls by their visible labels, never by position alone.
- To create the Triage encounter:
  - Start a new encounter via the 'New Encounter' button on Jane Sample's record.
  - Select 'Triage' as the encounter type by clicking the button labeled exactly 'Triage'.
  - Enter the exact note requested into the 'Note' textarea: `Triage: knee pain, ice and rest, follow up in two weeks.`
  - Click 'Save Encounter' once to save the record.
- After saving, confirm the screen shows the encounter saved message for Jane Sample.
- Stop once the encounter is saved successfully; do not repeat saving or enter data multiple times.
- If an error occurs (e.g., save button missing or disabled, or timeout), do not retry blindly; instead, report failure.
- Always verify that the patient identifier on the screen matches the requested patient before writing.

- Report final status as 'saved' if the record shows saved successfully, or 'stopped' if stopping otherwise.

</file>

<notes>
The divergent moment between rollout base1 and base2 concerned the typing method into the note field (clicking before typing vs. just typing), but both succeeded. Both runs carefully confirmed the patient's identity before entry and saved only once.

No evidence showed tool errors needing fallbacks or repeated saving attempts, so none are prescribed here.

Text was clarified to explicitly read and confirm the patient record, to rely on controls' labels, and to avoid blind retries.

This leverages the key workspace fact visible in the screen IDs (#patient/p1) and patient details (Jane Sample, DOB 1980-01-01).

No skill component added, as the procedure is straightforward and tightly scoped.

This edit slightly expands and makes explicit the critical checks already observed in the rollouts, closing the gap where the original harness was too minimal and generic.

All instructions reflect the successful observed behavior exactly, with no new assumptions or domain judgments.
</notes>