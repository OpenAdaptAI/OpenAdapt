# Operating the clinical record application

This harness guides the agent to find the correct patient, enter the requested encounter data exactly as asked, and save it once only.

- ANALYTIC MOVE: Select and open the patient record by matching the full name and date of birth given in the task, never using partial or guessed matches.

- ARTIFACT CONTRACT: The encounter record must include:
    - Encounter type: selected as specified (e.g., "Triage")
    - Note text: matching exactly the given note text
    - Patient identity: confirmed by both name and DOB to avoid writes to the wrong chart

- DECISION RULE:
    - Trigger: when the task requests entering an encounter note for a named patient.
    - Evidence: confirm exact patient match in screen identifiers (name and DOB).
    - Stop and report "stopped" if the right patient cannot be found unambiguously.
    - Save the encounter once after entering all values as requested.
    - Explicitly avoid clicking Save multiple times.
    - If a save appears to have timed out or failed, report the uncertainty but do not retry endlessly.
    - Avoid duplicate submissions which cause record duplication.

- ENCODING: Always parse and confirm patient identity from screen headers showing name and date of birth. Use a skill for "ConfirmPatientWithDOB" (to be authored) invoked on opening the record. Confirm the exact note contents before saving.

- Reporting:
    - Upon a successful save, report "saved".
    - If stopped (patient not found or ambiguity), report "stopped".
    - Never silently retry saves multiple times when the screen shows uncertainty; instead report the status honestly.

- WARNINGS:
    - A write to the wrong patient is worse than no write.
    - Multiple save clicks may cause duplicated encounters; only save once.
    - A save reporting "timed out" makes the save outcome uncertain—do not retry blindly but report carefully.

This domain knowledge applies specifically to the MockMed Clinical demo application screens and the task of entering triage encounter notes.

