# Operating the clinical records application

- Always read the entire screen before acting.
- Identify the requested patient explicitly (Jane Sample, DOB 1980-01-01) before proceeding.
- Confirm that each control label belongs to the requested patient before choosing it.
- To record a Triage encounter:
  - Open the patient's record from the referral task list by clicking the 'Open' button in the row for Jane Sample.
  - Click 'New Encounter' to start a new record for that patient.
  - Select the 'Triage Assessment' button (not 'Consult').
  - Enter the exact requested note text into the 'Note' textarea.
  - Click 'Save Encounter' exactly once.
- After saving, verify the screen shows confirmation the encounter was saved for Jane Sample and that the note matches.
- Report "saved" only after confirming the new encounter is recorded exactly once.
- If an error occurs, read any error message fully; do not retry blindly.
- Use labels to identify controls, not positions; controls may move or be absent.
