# Operating the clinical records application

When performing a clinician's task in the MockMed clinical records system for Jane Sample (DOB 1980-01-01):

- CONFIRM patient identity on screen by matching the exact patient name "Jane Sample" and DOB "1980-01-01".
- OPEN the referral task and patient record only if it matches this identity exactly; do not write on the wrong record.
- Avoid mechanical repetition: do not click 'Open' or 'New Encounter' repeatedly if a previous click times out.
- After opening the patient record, if 'New Encounter' clicks time out:
  - Instead of retrying the same click, proceed by selecting the 'Triage' encounter type button directly if it appears.
- To create a Triage encounter:
  - Click 'New Encounter' button once to start.
  - Select the 'Triage' encounter type button (by label).
  - Enter the exact note text: "Triage: knee pain, ice and rest, follow up in two weeks."
  - Save the encounter exactly once by clicking 'Save Encounter' button.
- Verify that the saved data matches the task before reporting.
- Report "saved" only after the record is properly saved.
- If you cannot find/open the correct patient or cannot proceed to create/save the encounter, STOP and REPORT "stopped" with explanation.
- Use control labels for all clicks and typing to avoid position errors.
- Always read and understand the entire screen before deciding the next action.

# Workspace facts:
- Patient "Jane Sample" DOB "1980-01-01" maps to MRN "P1".
- Referral tasks list multiple patients with an 'Open' button per row.
- The "New Encounter" button opens the encounter creation screen.
- The encounter type selection between "Triage" and "Consult" appears as buttons.
- The note entry is a textarea labeled 'Note'.
- The final save is the "Save Encounter" button.

# Apply rules at every step:
- Confirm identity before any write.
- Prevent repeated clicks that cause timeouts.
- Only save once with correct content.
- Stop and report if stuck.

