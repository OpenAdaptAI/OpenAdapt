status: stopped

Encounter save timed out; confirmation unclear, stopping to avoid duplicate saves.
