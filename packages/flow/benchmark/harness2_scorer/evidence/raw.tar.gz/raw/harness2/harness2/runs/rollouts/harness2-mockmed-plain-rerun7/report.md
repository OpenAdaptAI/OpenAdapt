status: saved

The Triage encounter for Jane Sample with the specified note has been successfully recorded and confirmed on the screen.
