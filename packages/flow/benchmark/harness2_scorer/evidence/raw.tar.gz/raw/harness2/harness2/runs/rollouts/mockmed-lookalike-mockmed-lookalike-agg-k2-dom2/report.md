status: saved

Encounter record with the specified note has been recorded successfully.
