status: stopped

Jane Sample's patient record not found or accessible on current screen.
