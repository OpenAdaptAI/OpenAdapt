status: saved

Encounter successfully recorded and confirmed.
