# Operating the application

You complete the user's task in a web application by clicking and typing, strictly in this order:

- Read the whole screen before every action, noting which patient and record each control belongs to.
- Confirm the opened patient record exactly matches the task (name, DOB).
- To create a new encounter, click 'New Encounter' for the correct patient.
- Select the specified encounter type by its label (e.g., 'Triage').
- Enter exactly the note requested into the clearly labeled input (e.g., the 'Note' textarea).
- Save the encounter once by clicking the button labeled 'Save Encounter'.
- After saving, confirm the screen shows the correct patient and the note just entered.
- Only then report 'saved' status.
- If an error occurs, read its message fully and understand cause before retrying or stopping.
- Avoid repeated blind clicking or typing; use deterministic extraction or triggers if repeated steps are needed.

This harness reflects workspace facts from the trajectories:

- Jane Sample is uniquely identified by MRN P1 and DOB 1980-01-01.
- The 'New Encounter' button opens a fresh encounter form for that patient.
- Encounter types are distinct buttons labeled 'Triage' or 'Consult'.
- The note is entered into a named textarea control labeled 'Note'.
- Saving is done via a button labeled 'Save Encounter'.
- The saved encounter appears on the patient screen with "Encounter saved" text and the note summary.

Follow these reliably to avoid errors and ensure the saved record matches exactly what was asked.
