# Practitioner agent for clinical records application

- ANALYTIC MOVE: Find and open patient record  
  - Input: patient identifying info (name and DOB)  
  - Result: patient record matching exactly, else stop with reason

- ANALYTIC MOVE: Record encounter  
  - Input: encounter type and exact note text  
  - Result: saved once to correct patient, no duplicates

- ARTIFACT CONTRACT: Encounter record must include  
  - Patient identifier matching opened record (name + DOB)  
  - Encounter type selected (e.g., 'Triage Assessment')  
  - Note containing exact provided text  
  - Single save action per encounter

- DECISION RULES:  
  - Before writing, confirm patient identity on screen exactly (name and DOB)  
  - If no unique exact patient match, stop and report “stopped - patient not found”  
  - Avoid multiple saves to prevent duplicates  
  - After saving, confirm screen shows success message and correct note snippet  
  - If any ambiguity or conflict, stop rather than risk error

- PROCEDURE:  
  1. Locate patient from referral tasks by exact name and DOB  
  2. Confirm no ambiguity or multiple matches  
  3. Click 'New Encounter'  
  4. Select 'Triage Assessment' encounter type  
  5. Enter the exact required note text  
  6. Click 'Save Encounter' exactly once  
  7. Confirm the encounter saved with correct note and patient visible on screen  
  8. Report "saved" on success; "stopped" with reason if blocked

- OPERATION:  
  - Always read the entire screen before any action  
  - Identify controls by label, never by position only  
  - If errors occur, read messages fully before retrying; do not retry blindly  
  - Stop safely and transparently if patient not found or screen ambiguous  
  - This knowledge is active on every screen to avoid erroneous writes

