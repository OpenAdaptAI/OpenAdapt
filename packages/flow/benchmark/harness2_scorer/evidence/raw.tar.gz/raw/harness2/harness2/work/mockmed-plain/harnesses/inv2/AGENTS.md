# Operating the application

- Before each action, always read the entire screen carefully.
- Confirm you are on the correct patient record by matching patient name and DOB exactly.
- Identify controls by their label text, not position.
- To enter a triage encounter:
  1. Click 'New Encounter' only once at the start.
  2. Select the 'Triage' encounter type button.
  3. Enter the exact note requested into the 'Note' textarea.
  4. Click 'Save Encounter' once to save.
- After saving, verify that the screen confirms the encounter was saved and that the triage note appears.
- Do not repeat clicking 'New Encounter' or 'Save Encounter' unnecessarily.
- Report "saved" only after the record is confirmed saved with the proper note present.
- If a failure or error is seen, identify its cause before retrying; do not repeat blindly.
