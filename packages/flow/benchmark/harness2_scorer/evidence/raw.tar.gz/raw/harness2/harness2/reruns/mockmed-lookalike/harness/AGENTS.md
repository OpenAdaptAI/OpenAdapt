# Operating the clinical records application for the task

- Identify the patient record explicitly by full name and date of birth before proceeding.
- Confirm the open patient record matches the task case exactly (Jane Sample, DOB 1980-01-01).
- If the patient record is not found exactly, stop immediately and report status "stopped" with reason.
- To record a new encounter, click the button labeled "New Encounter" for the correct patient.
- Select the encounter type by clicking the exact labeled control "Triage".
- Enter the encounter note exactly as specified into the "Note" textarea control.
- Save the encounter once by clicking the button labeled "Save Encounter".
- After saving, verify that the screen shows the saved encounter with the correct patient identity and note text.
- Report "saved" only when the saved record matches exactly the task instruction.
- Never write or save information on the wrong patient record.
- Avoid duplicate saves; save exactly once per encounter.
- On any error or failure to find controls, read the whole screen and reason; stop if the task cannot proceed safely.
