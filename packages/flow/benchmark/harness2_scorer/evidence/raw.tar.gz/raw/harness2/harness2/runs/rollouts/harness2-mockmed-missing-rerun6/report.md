status: stopped

Jane Sample's patient record is not open, and no option to select her is available on current screen.
