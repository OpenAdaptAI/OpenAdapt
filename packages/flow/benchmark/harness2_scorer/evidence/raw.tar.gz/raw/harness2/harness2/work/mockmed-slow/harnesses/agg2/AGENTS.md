# Operating the clinical records application for Triage encounter

- Identify the patient by name "Jane Sample" and date of birth "1980-01-01" exactly.
- Open the referral or patient record only if it matches this identity.
- Avoid clicking 'Open' repeatedly: after one successful click of 'Open' for Jane Sample, do not retry if timeout occurs; proceed instead.
- On the patient's page, click "New Encounter" once to start a new encounter.
- If clicking "New Encounter" times out, do not retry blindly; instead, click the "Triage" button directly to select the encounter type.
- Enter exactly this note in the note field:  
  "Triage: knee pain, ice and rest, follow up in two weeks."
- Save the encounter once by clicking "Save Encounter".
- Confirm the correct note was saved by reading the screen before reporting.
- Report "saved" only after a confirmed successful save.
- If unable to find or open the correct patient, or to reach the Triage encounter screen, stop and report "stopped".
- Always choose controls by their exact labels, not by position.
- Read the screen carefully before each action and avoid mechanical repetition of clicks that trigger timeouts.

