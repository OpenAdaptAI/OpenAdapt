<file path="harness/AGENTS.md">
# Operating the clinical records application for a Triage encounter

- Before any write, confirm you have opened the correct patient record matching the requested patient (name, DOB).
- To start a Triage encounter:
  - Click "New Encounter".
  - Select the "Triage" encounter type button.
- Enter exactly the note text requested into the Note field.
- Click "Save Encounter" exactly once.
- Wait for confirmation on the same patient record screen that the encounter note was saved.
- If the correct patient record cannot be opened, stop with reason.
- If duplicate or multiple submissions risk exists, avoid saving more than once per encounter.
- Report "saved" only after confirmation the encounter is recorded in that patient's record.
- Report "stopped" only if unable to find or open the correct patient record or safely progress.

# Domain knowledge derived from this workspace

- The patient record screen identifies the patient by name and DOB in the header line.
- The record of saved encounters appears below with the note text visible.
- Encounter types are selected by clicking the corresponding button ("Triage").
- The Note field is a textarea accepting free text exactly as given.
- The Save Encounter button persists the entry; it must be clicked once and only once per encounter.
- After saving, the screen updates showing "Encounter saved —" and the note text listed under Encounters.
- The "New Encounter" button appears on the patient record screen after saving.
- The patient's MRN code on screen is for verification only, not to be invented or relied on for writes.

# Summary

Complete the task by precisely entering the given note in a single Triage encounter on the correct patient record, save once, then verify the saved record before reporting success. Stop safely if the correct patient is not found.

</file>

<notes>
I enhanced AGENTS.md to encode domain-anchored, checkable practitioner knowledge explicitly for this Triage encounter task:

- Added rules grounding patient identity verification by name and DOB per workspace observations.
- Specified the exact sequence of UI actions: open correct patient, "New Encounter", select "Triage", enter exact note, save once, confirm saved record shows note.
- Included conditions to stop early with reason if correct record cannot be found.
- Clarified the unique Save Encounter click as per workspace evidence that multiple save clicks time out and cause errors.
- Added details on how saved encounters appear on the patient screen as confirmation.
- Avoided any invented standards or IDs, relying only on observed UI labels and patient identity data visible.
- This matches the successful rollout (base2) and prevents failure mode seen in base1 where save was repeatedly attempted with timeout.
- Kept instructions concise for practical application and agent reading on each screen before acting.

This edit directly addresses divergence shown by base1’s repeated save button failures and the need to confirm saves only once per encounter; it ensures the agent will detect the correct patient identity, do exactly one save, then confirm success before reporting. All facts are grounded in the observed workspace UI and trajectories.
</notes>