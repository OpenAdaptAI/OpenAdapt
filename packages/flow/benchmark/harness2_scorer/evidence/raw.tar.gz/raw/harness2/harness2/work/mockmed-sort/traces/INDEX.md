# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-sort-mockmed-sort-agg-k2-agg1](traces/mockmed-sort-mockmed-sort-agg-k2-agg1/trace.md) | mockmed/sort | agg1 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-base1](traces/mockmed-sort-mockmed-sort-agg-k2-base1/trace.md) | mockmed/sort | base1 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-base2](traces/mockmed-sort-mockmed-sort-agg-k2-base2/trace.md) | mockmed/sort | base2 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-dom1](traces/mockmed-sort-mockmed-sort-agg-k2-dom1/trace.md) | mockmed/sort | dom1 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-dom2](traces/mockmed-sort-mockmed-sort-agg-k2-dom2/trace.md) | mockmed/sort | dom2 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-inv1](traces/mockmed-sort-mockmed-sort-agg-k2-inv1/trace.md) | mockmed/sort | inv1 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-inv2](traces/mockmed-sort-mockmed-sort-agg-k2-inv2/trace.md) | mockmed/sort | inv2 | verified | 1.0 |  |  |
| [mockmed-sort-mockmed-sort-agg-k2-agg2](traces/mockmed-sort-mockmed-sort-agg-k2-agg2/trace.md) | mockmed/sort | agg2 | wrong_effect | -0.5 |  |  |
