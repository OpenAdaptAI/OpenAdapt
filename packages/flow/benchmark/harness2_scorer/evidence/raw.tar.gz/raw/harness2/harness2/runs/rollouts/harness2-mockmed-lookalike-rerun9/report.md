status: saved

The encounter has already been entered and saved successfully.
