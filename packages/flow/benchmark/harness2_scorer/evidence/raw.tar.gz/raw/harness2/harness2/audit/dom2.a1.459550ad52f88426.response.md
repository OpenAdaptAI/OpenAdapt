<file path="harness/AGENTS.md">
# Operating the clinical records application

- Before any data entry, confirm the patient's identity by matching name and DOB exactly.
- If the correct patient record is not found, stop and report why.
- Begin a new Triage encounter only after confirming no duplicate exists for current input.
- Select the 'Triage' encounter type explicitly.
- Enter the exact note text provided by the task with no additions or omissions.
- Save the encounter exactly once; confirm the screen shows confirmation of successful save.
- Avoid any second save or submission that would duplicate the encounter in the record.
- Report "saved" only after successful save confirmation on the patient's chart.
- If uncertainty remains about the patient's identity or encounter saved state, stop and report the issue.
</file>

<notes>
I revised AGENTS.md to encode clear, actionable checks grounded in the workspace facts and task evidence:

- Matching patient identity on name and DOB to ensure writes go to correct chart. Both rollout trajectories showed navigation to Jane Sample with MRN P1 and DOB 1980-01-01. This is critical to avoid wrong-patient writes.

- Stopping if the patient cannot be found or is uncertain (a requirement given "a write on the wrong patient's chart is worse than no write").

- Avoiding duplicate records by saving the encounter exactly once, because repeated saves create duplicates as known from domain rules.

- Explicitly selecting the 'Triage' encounter type as seen done in all rollouts.

- Entering the exact provided note text without additions or omissions, per the task and rollout.

- Confirming the save via the "Encounter saved" screen message before reporting saved status.

- Stopping if uncertainty remains about patient or save status.

This harness captures the domain knowledge “what the practitioner knows” about risk and correctness for this particular task family, using evidence from both trajectories (base1 and base2). This should prevent confusion that caused repeated saves in base1.

No skills were added since the domain knowledge here is simple and directly mapped to the UI in this task, and the task family is limited to recording an encounter with one note. The guidelines prohibit duplicating generic procedure here or adding ungrounded authority.

I removed the very generic and minimal existing instructions, replacing them with explicit practitioner knowledge rules that address the documented errors and risks observed.
</notes>