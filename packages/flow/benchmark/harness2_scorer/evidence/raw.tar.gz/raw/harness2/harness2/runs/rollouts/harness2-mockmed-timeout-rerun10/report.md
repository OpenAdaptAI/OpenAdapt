status: stopped

Encounter save status uncertain; manual verification needed.
