status: saved

Triage encounter for Jane Sample saved with the correct note.
