status: stopped

Save timed out — the encounter may or may not have been saved.
