<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in the clinical records application as follows:

- Read the entire screen carefully before acting.
- Confirm you are working with the correct patient before any data entry:
  * Check patient name and DOB on the screen to match the requested patient.
- Navigation:
  * Open the referral matching the requested patient by matching patient name in the referral list.
  * If clicking 'Open' repeatedly times out, on the next screen attempt, skip clicking 'Open' again and proceed to encounter creation.
- Encounter creation:
  * When on the patient record screen, locate and click the 'New Encounter' button by label.
  * If clicking 'New Encounter' times out, proceed to click the 'Triage' button directly on the encounter screen.
- Encounter data entry:
  * Select the 'Triage' encounter type button by label to create the correct encounter type.
  * Enter the exact note requested into the 'Note' textarea control by label.
- Save once:
  * Click the 'Save Encounter' button once after entering all requested data.
  * Confirm the record saved by revisiting or refreshing the encounter list, ensuring the entered note is present.
- Reporting:
  * Report “saved” after a successful save confirmed by screen evidence.
  * Report “stopped” if you cannot proceed due to timeout or error, after following bounded fallback.

- After any error or timeout:
  * Investigate the screen to understand what happened before retrying a different action.
  * Do not blindly repeat the same click that caused a timeout.

- Choose controls and buttons by their exact labels, not positions.
- Preserve evidence of your actions and confirmations in your report.

</file>

<notes>
I focused on tracing the repeated divergence found in the two base rollouts: the agent kept clicking the 'Open' or 'New Encounter' button multiple times leading to timeout, and neither rollout reached entering the note or saving. The evidence shows that after timeout on clicking 'New Encounter', the UI displays the 'Triage' and 'Consult' buttons and a 'Note' textarea, which the agent can use directly to create and document the encounter.

Thus, I added rules:

- Always confirm patient's identity on screen before writing.
- On first timeout clicking 'Open' or 'New Encounter', do not retry blindly; instead proceed to next logical step (click 'Triage' button).
- Explicitly pick controls by label rather than position.
- Enter the exact note into 'Note' textarea.
- Save once after entering data.
- Confirm the saved record by rereading the screen content.
- Stop with a proper report if stuck.

This matches the exact moments in rollouts base1.md and base2.md where timeout forced a change of approach and the rollouts failed to finish.

No professional or domain judgments were added; the agent's workflow is made robust and evidence-grounded per instructions.
</notes>