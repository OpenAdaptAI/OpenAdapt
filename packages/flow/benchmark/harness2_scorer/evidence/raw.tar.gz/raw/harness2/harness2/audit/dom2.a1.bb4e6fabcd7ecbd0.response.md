<file path="harness/AGENTS.md">
# Operating the application

You complete the user's task in a web application by clicking and typing.

- Before writing, confirm you have opened the correct patient's record by matching both the patient name and date of birth exactly (e.g., Jane Sample, DOB 1980-01-01).
- Avoid making any entries or saves on the wrong patient's chart.
- Open the patient record only once; do not submit multiple encounters for the same task to avoid duplicates.
- To create the Triage encounter:
  - Locate and click the 'New Encounter' button.
  - Select the 'Triage' encounter type if not already selected.
  - Enter exactly the required note text.
  - Save the encounter once.
- If the correct patient cannot be found or the Triage encounter screen cannot be reached, stop and report with explanation.
- Report "saved" after saving the encounter; report "stopped" if you halt early.

</file>

<notes>
I expanded the agent's instructions to incorporate the most critical practitioner knowledge found missed in runs base1 and base2:

- Explicit patient identity check using both name and DOB to avoid wrong chart writes, as warned in the brief.
- Avoid duplicate submissions by opening only once and saving just once per encounter task.
- Clear steps to create the Triage encounter: click 'New Encounter', select 'Triage' type if needed, enter exact note, save once.
- Instruction to stop and explain if unable to find or open the correct patient or the encounter creation screen.
- Clear reporting instructions: report "saved" on success and "stopped" on halting.

This directly addresses the trajectories' failures where the agent repeated clicks on "New Encounter" (timeouts) and did not report its final status.

No reusable skill was added because the workflow and checks are concise and specific to this task's data and UI states.

The single moment traced to is from base1 and base2 step 12-13, where the agent clicks 'Triage' but does not proceed correctly through the steps or report. The harness correction clarifies the required checks and the exact patient identity that must be verified before any edits.

This prevents the risk seen of writing to the wrong patient, duplicating encounters, or not reporting completion states.

No invented standards or authority citations are introduced. The rules are drawn solely from practitioner safety-based instructions and the concrete handle on the UI flows observed in the evidence.

The short form fits the existing concise style and improves agent correctness without extra cognitive load.
</notes>