# Traces

Every trace is complete: each screen, action, reason and error, the identity
check at each write, and the read-back from the system of record.

| trace | task | candidate | outcome | reward | wrong record | duplicate |
|---|---|---|---|---|---|---|
| [mockmed-lookalike-mockmed-lookalike-agg-k2-agg1](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-agg1/trace.md) | mockmed/lookalike | agg1 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-agg2](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-agg2/trace.md) | mockmed/lookalike | agg2 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-base1](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-base1/trace.md) | mockmed/lookalike | base1 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-base2](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-base2/trace.md) | mockmed/lookalike | base2 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-dom1](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-dom1/trace.md) | mockmed/lookalike | dom1 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-dom2](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-dom2/trace.md) | mockmed/lookalike | dom2 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-inv1](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-inv1/trace.md) | mockmed/lookalike | inv1 | verified | 1.0 |  |  |
| [mockmed-lookalike-mockmed-lookalike-agg-k2-inv2](traces/mockmed-lookalike-mockmed-lookalike-agg-k2-inv2/trace.md) | mockmed/lookalike | inv2 | verified | 1.0 |  |  |
