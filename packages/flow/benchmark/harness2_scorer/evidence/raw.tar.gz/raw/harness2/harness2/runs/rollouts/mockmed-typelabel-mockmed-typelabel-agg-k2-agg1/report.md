status: saved

Encounter successfully recorded and saved for Jane Sample with note confirming 'Triage: knee pain, ice and rest, follow up in two weeks.'
