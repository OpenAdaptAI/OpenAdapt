# Operating the clinical record application

- Before starting, find and open the correct patient's record by an exact match on full name and date of birth.
- Confirm the patient shown matches the task details exactly (e.g., Jane Sample, DOB 1980-01-01).
- Only add or edit an encounter under the confirmed patient record.
- Select the encounter type as specified, e.g., 'Triage'.
- Enter exactly the note text as requested; do not alter or add information.
- Click the 'Save Encounter' button exactly once per record entry.
- After clicking save:
  - Carefully check for confirmation that the encounter saved successfully.
  - If you see a "Save timed out — the encounter may or may not have been saved" message or other uncertainty, do NOT attempt repeated saves.
  - Instead, stop and report "stopped: save status uncertain".
- If the patient cannot be found unambiguously, stop and report "stopped: patient not found".
- Avoid creating duplicate encounter records.
- Always produce a final report:
    - "saved" if the encounter was saved definitively,
    - or "stopped: reason" if halted or uncertain.
- Do not rely on position to choose controls; use visible labels or explicit control roles.
- Before every action, read the entire screen carefully to understand context and verify patient and controls.
- Never proceed without confirming patient identity and exact note content.
