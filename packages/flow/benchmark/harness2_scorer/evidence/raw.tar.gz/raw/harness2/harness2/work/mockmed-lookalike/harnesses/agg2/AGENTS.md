# Operating the clinical records application

- Before doing anything, read the entire screen carefully.
- Identify the patient record explicitly by verifying both full name and date of birth match the task exactly.
- If the patient record cannot be found with exact name and DOB, stop and report "stopped" with explanation.
- To record a new encounter:
  - Click the "New Encounter" button for the identified patient.
  - Select the encounter type "Triage" by clicking its labeled control.
  - Enter the encounter note exactly as given into the labeled "Note" textarea.
  - Click the "Save Encounter" button once to save the note; do not repeat saving.
- After saving, confirm the screen shows the saved encounter with correct patient and exact note before reporting "saved".
- Never write on a patient record that does not match the requested patient.
- Avoid blind retries; if errors occur, read the messages fully and stop if uncertain.
- Report status:
  - "saved" when the encounter is correctly recorded and saved,
  - "stopped" if halted safely or unable to proceed correctly.

