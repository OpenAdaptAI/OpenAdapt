<file path="harness/AGENTS.md">
# Operating the clinical records application

The agent acts as a practitioner entering a single Triage encounter for one patient, exactly as specified.

- Before doing any data entry, confirm that the open patient record matches the target patient, Jane Sample, DOB 1980-01-01 exactly. If the right patient cannot be confirmed or found, stop and report why.
- Use the controls labeled visibly on screen; never rely on control position or unconfirmed IDs.
- To enter the encounter:
  - Click 'New Encounter' once to start.
  - Click the encounter type button labeled 'Triage'.
  - Enter the exact note text provided by the task in the 'Note' textarea field.
  - Click 'Save Encounter' once to save the note.
- After saving, verify the encounter is saved by confirming the screen shows the exact note under 'Encounter saved' and the patient identity remains correct.
- Avoid duplicate entries by saving only once per encounter.
- Never proceed blindly if uncertainty or ambiguity arises about patient identity or save confirmation.
- Stop safely and explain with status if any step cannot be verified or fails.
- Report "saved" only after the encounter is correctly saved and confirmed exactly once.

Include and use the skill `enter-encounter` for detailed operational steps.

</file>

<file path="harness/skills/enter-encounter/SKILL.md">
---
name: enter-encounter
description: |
  Procedure to accurately record a single Triage encounter for the specified patient.

  Inputs:
    - patient_name: the full patient name, e.g., "Jane Sample"
    - patient_dob: the date of birth string, e.g., "1980-01-01"
    - note_text: exact note text to enter

  Outputs:
    - status: "saved" if successful, "stopped" if aborted
    - explanation: text explaining reason if stopped

  Steps:
    1. Verify the currently open patient record matches patient_name and patient_dob exactly by reading screen header.
       - If not matched or ambiguous, stop with explanation.
    2. Click the button labeled 'New Encounter' exactly once to start a new record.
    3. Click the button labeled 'Triage' to select the encounter type.
    4. Enter note_text exactly into the textarea control labeled 'Note'.
    5. Click the button labeled 'Save Encounter' exactly once.
    6. After save, confirm that the screen displays "Encounter saved" and that note_text appears exactly as saved associated with 'Triage' under that patient record.
       - If confirmation fails or ambiguous, stop with explanation.
    7. Report status "saved" on successful confirmation.

  Domain checks and constraints:
    - Do not submit if patient identity is unclear or mismatched.
    - Avoid duplicate saves; save only once per encounter.
    - Use only visible labels to identify interactive elements.
    - Stop safely if uncertain or any verification fails.

</file>

<notes>
dropped -> KEEP_BASE -> both base rollouts repeatedly clicked 'New Encounter' and 'Save Encounter' causing redundant saves, confirming existing harness is insufficient for reliable completion (fails repeated 2/2 base runs)
kept -> pool/dom1 (DOM1) -> detailed domain rules and explicit patient ID and save confirmation checks prevent wrong-patient writes and duplicated encounters; rollout shows safe, correct exact task completion (success 1/1 rollout)
kept -> pool/inv1 (INV1) -> explicit instructions to read full screen, confirm identity, save only once, and verify saved note fix repeated save loops seen in base1 (improves reliability in 1/1 rollout)
dropped -> pool/inv2 (INV2) -> introduced an unneeded early click on 'Consult' first before 'Triage' (step 2->3) which is extra and risks confusion; less clean sequence than INV1
dropped -> pool/dom2 (DOM2) -> less comprehensive in domain checks, no skill included, no explicit detailed confirmation steps seen in DOM1, a step back from DOM1 clarity and robustness
merged -> DOM1 + INV1 -> combine DOM1's rich domain knowledge and explicit fail-safes with INV1's precise operational rules including never double save, read screen fully, control selection by label, explicit procedural stops on errors; adopt the skill enter-encounter from DOM1 for operation
omit INV2 and DOM2 as less complete or precise per rollout and documented trajectory evidence
</notes>