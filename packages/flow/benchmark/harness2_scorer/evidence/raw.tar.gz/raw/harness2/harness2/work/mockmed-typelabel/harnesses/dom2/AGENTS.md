# Practitioner harness for clinical record entry

- ANALYTIC MOVE: Confirm patient identity by matching full name and DOB on the patient record screen before any write.
- ARTIFACT CONTRACT: New Encounter record must have: 
  - Encounter Type specifically selected (e.g., 'Triage Assessment').
  - Note field containing the exact prescribed text.
  - Record saved once per encounter to avoid duplicates.
- DECISION RULE: 
  - Trigger: task requires entering a Triage encounter note for Jane Sample DOB 1980-01-01.
  - Evidence: Patient screen must show exact name and DOB before creating or editing encounters.
  - Conflict: If patient identity does not match exactly, stop and report "stopped - patient not found".
  - Uncertainty: If multiple patient matches or screen ambiguity arises, do not proceed.
- PROCEDURE:
  1. Locate patient record with exact name and DOB.
  2. Confirm no prior saved encounter exists with same note text to avoid duplicates.
  3. Click 'New Encounter'.
  4. Select 'Triage Assessment' as Encounter Type.
  5. Enter exact note text provided.
  6. Save encounter once.
  7. Verify "Encounter saved" confirmation shows with correct note snippet.
  8. Report success if all above passed, or stop if patient not found or other blocking mismatch.

- Encoding notes:
  - The patient identity check anchors record writes, minimizing wrong-chart writes.
  - Avoid multiple saves to prevent duplicate encounters.
  - Stopping transparently when patient not found is safer than writing incorrect data.
  - The exact mapping for patient name and DOB to screen title is verified in the workspace trajectories.
