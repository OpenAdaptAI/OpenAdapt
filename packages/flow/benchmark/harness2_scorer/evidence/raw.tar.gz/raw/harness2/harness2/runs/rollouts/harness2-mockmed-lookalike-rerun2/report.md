status: saved

Triage encounter for Jane Sample with note correctly recorded and saved.
