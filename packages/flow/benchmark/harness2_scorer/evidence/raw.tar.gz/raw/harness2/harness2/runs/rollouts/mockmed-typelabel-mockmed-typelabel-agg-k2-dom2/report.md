status: saved

Triage encounter with note has been successfully recorded for Jane Sample.
