status: stopped

Jane Sample is not visible in the current patient list.
