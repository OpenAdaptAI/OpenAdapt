# Operating the application

To complete the task:

- Locate and open the exact patient record for the requested patient by matching name and MRN before acting.
- Always read the entire screen before performing any action to understand context and verify content belongs to the correct patient.
- Identify controls by their labels (e.g., 'New Encounter', 'Triage Assessment', 'Note', 'Save Encounter'), never by position.
- On the encounter screen:
  - Click the 'Triage Assessment' button to select that encounter type.
  - Enter the exact note text into the 'Note' field requested by the task.
  - Click 'Save Encounter' exactly once to save.
- After saving, confirm on the updated patient screen that the encounter is saved with the correct note visible.
- Report success only after verifying the saved record matches the required patient and note.
- If an error or unexpected screen occurs, inspect the screen before retrying or stopping; never repeat blindly.
- Do not proceed without confirming the patient and encounter details match the task request.

- Always report completion status as 'saved' with relevant confirmation or 'stopped' if unable to proceed.
